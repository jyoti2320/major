<!DOCTYPE html>
<html lang="en" style="overflow:overlay">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
    integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous" />

  <link rel="stylesheet" href="./assets/style.css" />
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <script src="https://kit.fontawesome.com/8eb330855f.js" crossorigin="anonymous"></script>
  <title>Government Colleges</title>


  
</head>

<body>
<?php include 'header.php'; ?> 

<section style="background-color: #577590;">
      <div class="container inner-div" style="background-color: #fff;">
        <div class="row">
          <h1 class="col-heading">
            Government Polytechnic Colleges
          </h1>
          <div class="col-md-12" style="margin-top: 50px; margin-left: 0px; ">
            <div class="table-college college-tables">
              <table class="table table-bordered" style="overflow-x: auto;">
                <thead
                  style="
                    background: -webkit-linear-gradient(
                      to right,
                      #f8961e,
                      #f3722c
                    ); /* Chrome 10-25, Safari 5.1-6 */
                    background: linear-gradient(to right, #f8961e, #f3722c);
                    color: white;
                  "
                >
                  <tr>
                    <th scope="col">SI No.</th>
                    <th scope="col">Polytechnic Name & Address</th>
                    <th scope="col">Available Courses</th>
                    <th scope="col">Aprroved Seats</th>
                  </tr>
                </thead>
              </table>







            <table class="table table-bordered gtable" style="overflow-x: auto;">
              <tbody>
                <tr>
                  <th scope="row">1</th>
                  <td>
                    Government Polytechnic, Ghaziabad <br/>
                    Phone No.: 0120-2719500 (O),(R)
                  </td>
                  <td>
                    <p>Civil Engg.</p>
                    <p>Mech. Engg. (Prod.)</p>
                    <p>Mech. Engg. (Spl. in CAD)</p>
                    <p>Mech. Engg. (Auto) Electronics Engg.</p>
                    <p>Information Technology</p>
                    <p>Mass Communication</p>
                    <p>Interior Design & Decoration</p>
                    <p>PGD in Computer Hardware & Networking</p>
                    <p>PGD in Web Designing</p>
                  </td>
                  <td>
                    <p>67</p>
                    <p>67</p>
                    <p>67</p>
                    <p>67</p>
                    <p>67</p>
                    <p>67</p>
                    <p>75</p>
                    <p>75</p>
                    <p>75</p>
                    <p>75</p>
                  </td>
                </tr>

                <tr>
                  <th  scope="row">2</th>
                  <td >
                    Km. Mayawati Government Girls Polytechnic, Badalpur
                    (Gautambudh Nagar)

                    <br />
                    Phone No.: 0120-2673540(O), 0120-2961001( R),
                  </td>
                  <td >
                    <p>Electronics Engg.</p>
                    <p>Computer Science & Engg.</p>
                    <p>PGD in Computer Hardware & Networking.</p>

                    <p>PGD in Web Designing</p>
                  </td>
                  <td>
                    <p>75</p>
                    <p>75</p>
                    <p>Not Running</p>
                    <p>Not Running</p>
                  </td>
                </tr>

                <tr>
                  <th  scope="row">3</th>
                  <td >
                    S. G. S. J. Polytechnic, Khurja

                    <br />
                    Ph No:05738-232020
                  </td>
                  <td>
                    <p>Civil Engg.</p>
                    <p>Electrical Engg.</p>
                    <p>Mech. Engg. (Production)</p>

                    <p>Glass & Ceramic Engg.</p>
                    <p>Architectura Assistantship</p>
                  </td>
                  <td>
                    <p>60</p>
                    <p>60</p>
                    <p>60</p>
                    <p>60</p>
                    <p>60</p>
                  </td>
                </tr>

                <tr>
                  <th  scope="row">4</th>
                  <td >
                    Chaudhry Mukhtar Singh Government Girls Polytechnic, Daurala (Meerut)

                    <br />
                    Ph No.01237-231699
                  </td>
                  <td >
                    <p>Electronics Engg.</p>
                    <p>Computer Science & Engg.</p>
                    <p>Information Technology</p>

                  </td>
                  <td>
                    <p>75</p>
                    <p>75</p>
                    <p>75</p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">5</th>
                  <td >
                    Government Polytechnic, Moradabad

                    <br />
                    Ph No:0591-2450095(O)
                  </td>
                  <td >
                    <p>Civil Engg.</p>
                    <p>Electrical Engg.</p>
                    <p>Mech. Engg. (Production)</p>


                  </td>
                  <td>
                    <p>75</p>
                    <p>75</p>
                    <p>75</p>

                  </td>
                </tr>
                <tr>
                  <th  scope="row">6</th>
                  <td >
                    Government Polytechnic, Bijnore

                    <br />
                    Phone No.: 01342-262982(O)
                  </td>
                  <td >
                    <p>Civil Engg.</p>
                    <p>Mech. Engg. (Maint. Engg.)</p>
                    <p>Electronics Engg.</p>
                    <p>Computer Science & Engg.</p>
                  </td>
                  <td>
                    <p>67</p>
                    <p>67</p>
                    <p>67</p>
                    <p>67</p>

                  </td>
                </tr>
                <tr>
                  <th  scope="row">7</th>
                  <td >
                    Government Polytechnic, Rampur

                    <br />
                    PhNo.0595-2351958(O)
                  </td>
                  <td >
                    <p>Electronics Engg.</p>
                    <p>Instrumentation & Control

                    </p>
                    <p>Electrical with Industrial Control</p>
                    <p>Electrical Engg.</p>
                    <p>Computer Science & Engg.</p>
                  </td>
                  <td>
                    <p>60</p>
                    <p>60</p>
                    <p>60</p>
                    <p>60</p>
                    <p>60</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">8</th>
                  <td >

                    Government Girls Polytechnic, Moradabad

                    <br />
                    Ph No.0591-2450365(O)
                  </td>
                  <td >
                    <p>Electronics Engg.</p>
                    <p>Electrical Engg.</p>
                    <p>Computer Science & Engg.</p>
                  </td>
                  <td>
                    <p>75+6</p>
                    <p>75</p>
                    <p>75</p>

                  </td>
                </tr>
                <tr>
                  <th  scope="row">9</th>
                  <td >

                    Mahamaya Polytechnic of Information & Technology, Jyotiba Phule Nagar,Amroha

                    <br />

                  </td>
                  <td >
                    <p>Electronics Engg. </p>
                  </td>
                  <td>
                    <p>75</p>

                  </td>
                </tr>
                <tr>
                  <th  scope="row">10</th>
                  <td >
                    Government Polytechnic, Saharanpur

                    <br />
                    Phone No.: 0132-2764011(O)
                  </td>
                  <td >
                    <p>Electronics Engg.</p>
                    <p>P.G. Dip. in Computer Application</p>
                    <p>Modern office Mngt. & Sec. Practice</p>
                    <p>Computer Science & Engg.</p>
                    <p>PGD in Computer Hardware & Networking
                    </p>
                    <p>PGD in Web Designing</p>
                  </td>
                  <td>
                    <p>67</p>
                    <p>75</p>
                    <p>75</p>
                    <p>67</p>
                    <p>75</p>
                    <br>
                    <p>Not Running</p>

                  </td>
                </tr>
                <tr>
                  <th  scope="row">11</th>
                  <td >
                    Savitri Bai Phule Government Girls Polytechnic, Saharanpur


                    <br />
                    Phone No.: 0132-2786473(O)


                  </td>
                  <td>
                    <p>Electronics Engg.</p>
                    <p>Computer Science & Engg.</p>
                    <p>Modern office Mngt. & Sec. Practice

                    </p>
                    <p>Civil Engg.</p>
                  </td>
                  <td>
                    <p>75</p>
                    <p>75</p>
                    <p>Not Running</p>
                    <p>75</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">12</th>
                  <td >
                    Government Girls Polytechnic, Shamli (Muzaffarnagar)




                    <br />

                    Phone No.:01398-251742(O)



                  </td>
                  <td >
                    <p>Electronics Engg.</p>
                    <p>Computer Science & Engg.</p>
                    <p>Fashion Design & Garment Technology</p>
                    <p>Modern office Mngt. & Sec. Practice</p>
                    <p>PGD in Accountancy (With Comp. Accounts & Taxation)</p>
                  </td>
                  <td>
                    <p>60</p>
                    <p>60</p>
                    <p>60</p>
                    <br>
                    <p>Not Running</p>
                    <p>Not Running</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">13</th>
                  <td >
                    Government Leather Instt., Agra


                    <br />
                    Phone No.: 0562-2281104(O)

                  </td>
                  <td >
                    <p>Leather Technology (Tanning)</p>

                    <p>Leather Tech.-Footwear (CAD Shoe)</p>

                    <p>Sadlery & Export Management</p>

                    <p>Computer Science & Engg.</p>


                  </td>
                  <td>
                    <p>75</p>
                    <p>75</p>
                    <p>Not Running</p>
                    <p>75</p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">14</th>
                  <td >
                    Government Polytechnic, Soron (Eta)
                    <br />
                    Phone No.: 05744-273371(O)
                  </td>
                  <td >
                    <p>Civil Engg.( Environment & Pollution Control)</p>

                    <p> Mech. Engg. (Prod.)</p>

                    <p>Architectural Assistantship</p>
                  </td>
                  <td>
                    <p>60</p>
                    <p>60</p>
                    <p>60</p>
                  </td>
                </tr> 
                <tr>
                  <th  scope="row">15</th>
                  <td >
                    Government Polytechnic, Mainpuri
                    <br />
                    Phone No.: 05672-234428(O)
                  </td>
                  <td >
                   <p>Electronics Engg.</p>

                   <p>Instrumentation & Control</p> 
                    
                  <p>Electronics with Spl. in Microprocessor</p> 
                  </td>
                  <td>
                    <p>67</p>
                    <p>67</p>
                    <p>67</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">16</th>
                  <td>
                    Government Poly, Firozabad
                    <br />
                    Ph.05612-265921(O)
                  </td>
                  <td >
                  <p>Glass & Ceramic Engg.</p>

                   <p>Mech. Engg. (Production)</p>
                    
                   <p>Chemical Engg.</p> 
                  </td>
                  <td>
                    <p>75</p>
                    <p>75</p>
                    <p>75</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">17</th>
                  <td >
                     	
                    Mahamaya Polytechnic of Information Technology, Mahamaya Nagar (Hathras)
                    <br />
                    
                  </td>
                  <td >
                   <p>Electronics Engg.</p>

                   <p> Computer Science and Engg. 
                    (New Course) 
                   </p>
                   <p> Information Technology(New Course)</p>
                  </td>
                  <td>
                    <p>75</p>
                    <p>75</p>
                    <br>
                    <p>75</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">18</th>
                  <td >

                    Government Polytechnic, Tundla

                    <br />
                  </td>
                  <td >
                 <p>Mech. Engg. (Production)</p>

                  <p>Civil Engg.</p>
                  
                 <p>Plastic Mould Technology</p>
                  </td>
                  <td>
                    <p>56</p>
                    <p>56</p>
                    <p>56</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">19</th>
                  <td >
                    Government Polytechnic, Changipur, Noorpur	
                    <br />
                  </td>
                  <td >
                 <p>	
                  Civil Engg.</p>
                  
                 <p> Computer Science and Engg.</p>
                  
                 <p>Textile Technology </p>
                  </td>
                  <td>
                    <p>75</p>
                    <p>75</p>
                    <p>75</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">20</th>
                  <td>
                    Government Polytechnic, Mankera, Agra
                    <br />
                  </td>
                  <td >
                  <p>Mech. Engg. (Prod.)</p>

                   <p>Civil Engg.</p>
                    
                   <p>Chemical Engg.</p>
                  </td>
                  <td>
                    <p>37</p>
                    <p>37</p>
                    <p>37</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">21</th>
                  <td >
                    Government Polytechnic, Sutavali,  Amroha 
                    <br />
                  </td>
                  <td >
                  <p>Mech. Engg. (Prod.)</p>
                   <p>Chemical Engg.</p>
                   <p>Chemical Engg. (spl. in Perto Chemical)</p>
                  </td>
                  <td>
                    <p>75</p>
                    <p>75</p>
                    <p>75</p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">22</th>
                  <td >
                    Government Polytechnic, Sahabad, Rampur
                    <br />
                  </td>
                  <td >
                  <p>Mech. Engg. (Prod.)</p>

                   <p>Civil Engg.</p>
                    
                  <p> Electrical Engg.</p>
                  </td>
                  <td>
                    <p>75</p>
                    <p>75</p>
                    <p>75</p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">23</th>
                  <td >
                    Government Poly, Sikandrarao, Etah
                    <br />
                  </td>
                  <td >
                 <p>	
                  Mech. Engg. (Prod.)</p>
                  
                 <p> Civil Engg.</p>
                  
                 <p> Electrical Engg.</p>
                  </td>
                  <td>
                    <p>37</p>
                    <p>37</p>
                    <p>37</p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">24</th>
                  <td >
                    Government Polytechnic, Chacha, Bhogaon, Mainpuri
                    <br />
                  </td>
                  <td >
                 <p>Mech. Engg. (Prod.)</p>

                 <p> Civil Engg.</p>
                  
                 <p> Electrical Engg.</p>	
                 
                  </td>
                  <td>
                    <p>60</p>
                    <p>60</p>
                    <p>60</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">25</th>
                  <td >
                    Government Polytechnic, Chandausi, Moradabad	
                    <br />
                  </td>
                  <td >
                 <p>
                  Civil Engg.</p>

                 <p> Chemical Engg.</p>
                  
                 <p> Printing Technology</p>
                  </td>
                  <td>
                    <p>60</p>
                    <p>60</p>
                    <p>60</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">26</th>
                  <td >
                    Government Polytechnic, Kotwan, Mathura (at G L I, Agra)
                    <br />
                  </td>
                  <td >
                 <p>
                  	
                 <p> Civil Engg.</p>

                 <p> Chemical Engg. (Spl. in Petro)</p>

                 <p> Paint Technolog (New Sllybus)</p>   
                  </td>
                  <td>
                    <p>75</p>
                    <p>75</p>
                    <p>75</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">27</th>
                  <td >
                  	Government Polytechnic, Debai, Bulandshar
                    <br />
                  </td>
                  <td >
                 <p>
                  Civil Engg.</p>

                 <p>Textile Technology</p>

                 <p>Textile Chemistry (New Sllybus)</p>
                  </td>
                  <td>
                    <p>60</p>
                    <p>60</p>
                    <p>60</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">28</th>
                  <td>
                    Mahamaya Polytechnic of Information Technology, Aligarh 
                    <br />
                  </td>
                  <td >
                 <p>
                  Civil Engg.</p>

                 <p> Electrical Engg.</p>
                  
                 <p>Computer Science and Engg.</p>
                  </td>
                  <td>
                    <p>75</p>
                    <p>75</p>
                    <p>75</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">29</th>
                  <td>
                    Government Polytechnic, Mawana Khurd, Meerut (at G.P. Bijnore)
                    <br />
                  </td>
                  <td >
                 <p>
                  Civil Engg.</p>

                  <p> Computer Science and Engg</p>

                  <p>Mechanical Engg. (Automobile)</p>
                  </td>
                  <td>
                    <p>75</p>
                    <p>75</p>
                    <p>75</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">30</th>
                  <td >
                    Government Polytechnic, Kirthal, Chaprauli, Bagpat (at G.P. Saharanpur)
                    <br />
                  </td>
                  <td >
                 <p>
                  Electronics Engg.</p>

                 <p>Electrical Engg.</p>
                  
                 <p>Mechnical Engg. (Prod.)(New Course)</p>
                  </td>
                  <td>
                    <p>67</p>
                    <p>67</p>
                    <p>67</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">31</th>
                  <td >
                    Government Polytechnic, Hindalpur, Hapur
                    <br />
                  </td>
                  <td >
                 <p>
                  Textile Chemistry</p>

                 <p>Electrical Engg. (Industrial Control)</p>                  
                 <p>Textile Technology</p>
                  </td>
                  <td>
                    <p>67</p>
                    <p>67</p>
                    <p>67</p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">32</th>
                  <td >
                    Mahamaya Polytechnic of Information Technology, Shamli (at G.P. Bijnore)
                    <br />
                  </td>
                  <td >
                 <p>
                  Mech. Engg. (Production)</p>

                 <p>Food Technology</p>
                  
                 <p>Paper and Pulp Technology</p>
                  </td>
                  <td>
                    <p>60</p>
                    <p>60</p>
                    <p>60</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">33</th>
                  <td >
                    Mahamaya Polytechnic of Information Technology, Kashganj (at G.P. Soron)
                    <br />
                  </td>
                  <td >
                 <p>
                  Mech. Engg. (Maintenance)</p>

                 <p>Electronics Engg.</p>
                  
                 <p>Electrical Engg.</p>
                  </td>
                  <td>
                    <p>60</p>
                    <p>60</p>
                    <p>60</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">34</th>
                  <td >
                    Government Polytechnic,  Arnia,  Bulandshar  (at  S.G.S.J.  Poly., Khurja)
                    <br />
                  </td>
                  <td >
                 <p>
                  Mech. Engg. (Production)</p>

                 <p> Civil Engg.</p>
                  
                 <p> Electrical Engg.</p>
                  </td>
                  <td>
                    <p>75</p>
                    <p>75</p>
                    <p>75</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">35</th>
                  <td >   	
                  Government Polytechnic,  Kotana, Barut, Bagpat  (at  G. P.,  Sutawali, Amroha)
                    <br />
                  </td>
                  <td >
                 <p>
                  Mech. Engg. (Automobile)</p>

                 <p>Civil Engg.</p>
                  
                 <p> Dairy Engg. (New Course)</p>
                  </td>
                  <td>
                    <p>75</p>
                    <p>75</p>
                    <p>75</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">36</th>
                  <td >   	
                    Government Polytechnic,  Jnasath, Muzaffarnagar   (at  G. P.,  Saharanpur)
                    <br />
                  </td>
                  <td >
                 <p>
                  Electronics Engg.</p>

                 <p>Mech. Engg. (Production)(New Course)</p>
                  
                 <p> Civil Engg.(New Course)</p>
                  </td>
                  <td>
                    <p>75</p>
                    <p>75</p>
                    <br>
                    <p>75</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">37</th>
                  <td >
                    Government Polytechnic, Kishni, Mainpuri  (New Poly.)       (at G.P.  ChhaChha Bhogoan, Mainpuri)
                  <br />

                  </td>
                  <td >
                    <p>Electrical Engg.</p>
                  </td>
                  <td>
                    <p>75</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">38</th>
                  <td >
                    Government Polytechnic, Shamsabad, Agra   (New Poly.)       (at G.P.   Mankera, Agra )
                  <br />

                  </td>
                  <td >
                    <p>Mechanical Engg.</p>
                  </td>
                  <td>
                    <p>75</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">39</th>
                  <td >
                    Government Polytechnic,Thakurdwara, Moradabad         (New Poly.)       (at G.P.   Moradabad )
                  <br />

                  </td>
                  <td >
                    <p>Mechanical Engg.(Prod.)</p>
                    <p>Architecture Assistantship</p>
                  </td>
                  <td>
                    <p>75</p>
                    <p>75</p>
                  </td>
                </tr>
                <tr>
                  <th  scope="row">40</th>
                  <td >
                    Government Polytechnic, Chamraua, Rampur   (New Poly.)       (at G.P.   Rampur )
                  <br />

                  </td>
                  <td>
                    <p>Computer Sc. and Engg.</p>
                  </td>
                  <td>
                    <p>37</p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">41</th>
                  <td >
                    Government Polytechnic, Katai Joya, J P Nagar  (New Poly.)       (at G.P.   Sutawali, Amroha )
                  <br />

                  </td>
                  <td >
                   <p>Mech. Engg. (Automobile)</p>
                   <p>Chemical Engg.</p>
                  </td>
                  <td>
                   <p>75</p>
                   <p>75</p>
                  </td>
                </tr>
                
               
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>


  <?php include 'footer.php'; ?>
  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="./assets/script.js"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
    integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
    integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"
    integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI"
    crossorigin="anonymous"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
</body>

</html>
