<!DOCTYPE html>
<html lang="en" style="overflow:overlay">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS -->
    <link
      rel="stylesheet"
      href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
      integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk"
      crossorigin="anonymous"
    />
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="./assets/style.css" />

    <script
      src="https://kit.fontawesome.com/8eb330855f.js"
      crossorigin="anonymous"
    ></script>
    <title> Aided College</title>
  </head>
  <body>
  <?php include 'header.php'; ?> 
  
   <section style="background-color: #ac36ac;">
      <div class="container inner-div" style="background-color: #fff;">
        <div class="row">
          <h1 class="col-heading">
            Aided Polytechnic Colleges
          </h1>
          <div class="col-md-12" style="margin-top: 50px; margin-left: 0px; ">
            <div class="table-college college-tables">
              <table class="table table-bordered">
                <thead
                  style="
                    background: -webkit-linear-gradient(
                      to right,
                      #f8961e,
                      #f3722c
                    ); /* Chrome 10-25, Safari 5.1-6 */
                    background: linear-gradient(to right, #f8961e, #f3722c);
                    color: white;
                  "
                >
                  <tr>
                    <th scope="col">SI No.</th>
                    <th scope="col">Polytechnic Name & Address</th>
                    <th scope="col">Available Courses</th>
                    <th scope="col">Aprroved Seats</th>
                  </tr>
                </thead>
              </table>

              <table class="table table-bordered gtable" >
                <tbody >
                    <tr>
                        <th scope="row">1</th>
                        <td >
                          Devnagari Polytechnic, Meerut
                          <br />
                          Phone No.: 0121-2440768(O)
                          <br />
                          Mob. 09219797017
                        </td>
                        <td >
                          <p>
                            Civil Engg.</p>
      
                           <p>Electrical Engg.</p>
                            
                           <p>Mech. Engg. (Production)</p>
                            
                           <p>P.G. Dip. in Computer Application</p>
                            
                           <p>P.G. Dip. in Biotechnology(Tissue Culture)</p>
                        </td>
                        <td>
                          <p>75</p>
                          <p>75</p>
                          <p>75</p>
                          <p>75</p>
                          <p>75</p>
                        </td>
                      </tr>
                      <tr>
                        <th scope="row">2</th>
                        <td >    	
                         D. J. Polytechnic, Baraut
                          <br />
                          Phone No.: 01234-262769(O)
                          <br />
                          Mob.09837239900
                        </td>
                        <td >
                          <p>
                            Civil Engg.</p>
      
                           <p>Electrical Engg.</p>
                            
                           <p>Mech. Engg. (Production)</p>
                        </td>
                        <td>
                          <p>60</p>
                          <p>60</p>
                          <p>60</p>
                        </td>
                      </tr>
                      <tr>
                        <th  scope="row">3</th>
                        <td >    	
                          Janta Polytechnic, Jhangirabad (Bulandshar)
                          <br />
                          Ph:05734260205(O)
                          Mob.09837239900
                        </td>
                        <td >
                          <p>
                            Civil Engg.</p>
      
                           <p>Electrical Engg.</p>
                            
                           <p>Mech. Engg. (Production)</p>
                        </td>
                        <td>
                          <p>50</p>
                          <p>75</p>
                          <p>75</p>
                        </td>
                      </tr>
                      <tr>
                        <th  scope="row">4</th>
                        <td>    	
                          Gandhi Polytechnic, Muzaffarnagar
                          <br />
                          Phone No.: 0131-2606741(O), 2433724(R) Mob. 09761762521
                        </td>
                        <td >
                          <p>
                            Civil Engg.</p>
      
                           <p>Electrical Engg.</p>
                            
                           <p> Mech. Engg. (Production)</p>
                            
                           <p>Mech. Engg. (Auto)</p>
                            
                           <p>Modern office Mngt. & Sec. Practice</p>
                        </td>
                        <td>
                          <p>67</p>
                          <p>67</p>
                          <p>67</p>
                          <p>67</p>
                          <p>75</p>
                        </td>
                      </tr>
                      <tr>
                        <th  scope="row">5</th>
                        <td >    	
                          Prem Mahavidyalay Polytechnic, Mathura
                          <br />
                          Phone No.: 0565-2530022(O)
                          <br />
                          Mob.09412521810
                        </td>
                        <td >
                          <p>
                            Civil Engg.</p>
      
                           <p>Electrical Engg.</p>
                            
                           <p> Mech. Engg. (Production)</p>
                            
                           <p>Mech. Engg. (Auto)</p>
                            
                           <p>Chemical Engg. (Petrochemical)</p>
                        </td>
                        <td>
                          <p>37</p>
                          <p>37</p>
                          <p>37</p>
                          <p>37</p>
                          <p>37</p>
                        </td>
                      </tr>
                      <tr>
                        <th  scope="row">6</th>
                        <td >    	
                          Balwant Rural Engg. Instt., Bichpuri, Agra
                          <br />
                          Phone No.: 0562-2776602(O), 2511161(R) Mob.09837038449
                        </td>
                        <td >
                          <p>
                            Civil Engg. (Environmental & Pollution Control)</p>
      
                           <p>Electrical Engg. (Industrial Control)</p>
                        </td>
                        <td>
                          <p>75</p>
                          <p>75</p>
                        </td>
                      </tr>
                      <tr>
                        <th  scope="row">7</th>
                        <td>    	
                          Murlidhar Gajanand Polytechnic, Hathras
                          <br />
                          Phone No.: 05722-233538(O)
                          <br />
                          Mob. 09219786480
                        </td>
                        <td>
                          <p>
                            Civil Engg.</p>
      
                           <p>Electrical Engg.</p>
                            
                           <p> Mech. Engg. (Production)</p>
                            
                           <p>Mech. Engg. (Auto)</p>
                            
                           <p>Electronics Engg.</p>
                           <p>Agriculture Engg.</p>
                        </td>
                        <td>
                          <p>56</p>
                          <p>56</p>
                          <p>56</p>
                          <p>56</p>
                          <p>56</p>
                          <p>56</p>
                        </td>
                      </tr>
                      <tr>
                        <th  scope="row">8</th>
                        <td >    	
                          Shri Anardevi Khandelwal Girls Polytechnic, Mathura
                          <br />
                          Phone No.: 0565-2407579(O), 2420688(R) Mob. 9457077698
                        </td>
                        <td >
                          <p>
                            Electronics Engg. (Modern Consumer Elect. Appliences)</p>
      
                           <p>Library and Information Science</p>
                            
                           <p>Modern office Management & Sec. Practice</p>
                        </td>
                        <td>
                          <p>37</p>
                          <br>
                          <p>75</p>
                          <p>75</p>
                        </td>
                      </tr>
                     
                    </tbody>
                  </table>
                    





                 
            </div>
          </div>
        </div>
      </div>
    </section>

    <?php include 'footer.php'; ?>
     <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="./assets/script.js"></script>
    <script
      src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
      integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
      integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"
      integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI"
      crossorigin="anonymous"
    ></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
  </body>
</html>