<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Admin Dashboard</title>

    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="style4.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
<style>
  /*
    DEMO STYLE
*/

@import "https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700";
body {
    font-family: 'Poppins', sans-serif;
    background: #fafafa;
}

p {
    font-family: 'Poppins', sans-serif;
    font-size: 1.1em;
    font-weight: 300;
    line-height: 1.7em;
    color: #999;
}

a,
a:hover,
a:focus {
    color: inherit;
    text-decoration: none;
    transition: all 0.3s;
}

.navbar {
    padding: 15px 10px;
    background: #fff;
    border: none;
    border-radius: 0;
  
    box-shadow: 1px 1px 3px rgba(0, 0, 0, 0.1);
}

.navbar-btn {
    box-shadow: none;
    outline: none !important;
    border: none;
}

.line {
    width: 100%;
    height: 1px;
    border-bottom: 1px dashed #ddd;
    margin: 40px 0;
}

i,
span {
    display: inline-block;
}

/* ---------------------------------------------------
    SIDEBAR STYLE
----------------------------------------------------- */

.wrapper {
    display: flex;
    align-items: stretch;
}

#sidebar {
    min-width: 250px;
    max-width: 250px;
    background: #f8961e;
    color: #fff;
    transition: all 0.3s;
}

#sidebar.active {
    min-width: 80px;
    max-width: 80px;
    text-align: center;
}

#sidebar.active .sidebar-header h3,
#sidebar.active .CTAs {
    display: none;
}

#sidebar.active .sidebar-header strong {
    display: block;
}

#sidebar ul li a {
    text-align: left;
}

#sidebar.active ul li a {
    padding: 20px 10px;
    text-align: center;
    font-size: 0.85em;
}

#sidebar.active ul li a i {
    margin-right: 0;
    display: block;
    font-size: 1.8em;
    margin-bottom: 5px;
}

#sidebar.active ul ul a {
    padding: 10px !important;
}

#sidebar.active .dropdown-toggle::after {
    top: auto;
    bottom: 10px;
    right: 50%;
    -webkit-transform: translateX(50%);
    -ms-transform: translateX(50%);
    transform: translateX(50%);
}

#sidebar .sidebar-header {
    padding: 20px;
    background: #f8961e;
}

#sidebar .sidebar-header strong {
    display: none;
    font-size: 1.8em;
}

#sidebar ul.components {
    padding: 20px 0;
    border-bottom: 1px solid #f3722c;
}

#sidebar ul li a {
    padding: 10px;
    font-size: 1.1em;
    display: block;
}

#sidebar ul li a:hover {
    color: #f3722c;
    background: #fff;
}

#sidebar ul li a i {
    margin-right: 10px;
}

#sidebar ul li.active>a,
a[aria-expanded="true"] {
    color: #fff;
    background: #f3722c;
}

a[data-toggle="collapse"] {
    position: relative;
}

.dropdown-toggle::after {
    display: block;
    position: absolute;
    top: 50%;
    right: 20px;
    transform: translateY(-50%);
}

ul ul a {
    font-size: 0.9em !important;
    padding-left: 30px !important;
    background: #f8961e;
}

ul.CTAs {
    padding: 20px;
}

ul.CTAs a {
    text-align: center;
    font-size: 0.9em !important;
    display: block;
    border-radius: 5px;
    margin-bottom: 5px;
}

a.download {
    background: #fff;
    color: #7386D5;
}

a.article,
a.article:hover {
    background: #f8961e !important;
    color: #fff !important;
}

/* ---------------------------------------------------
    CONTENT STYLE
----------------------------------------------------- */

#content {
    width: 100%;
    padding: 20px;
    min-height: 100vh;
    transition: all 0.3s;
}

/* ---------------------------------------------------
    MEDIAQUERIES
----------------------------------------------------- */

@media (max-width: 768px) {
    #sidebar {
        min-width: 80px;
        max-width: 80px;
        text-align: center;
        margin-left: -80px !important;
    }
    .dropdown-toggle::after {
        top: auto;
        bottom: 10px;
        right: 50%;
        -webkit-transform: translateX(50%);
        -ms-transform: translateX(50%);
        transform: translateX(50%);
    }
    #sidebar.active {
        margin-left: 0 !important;
    }
    #sidebar .sidebar-header h3,
    #sidebar .CTAs {
        display: none;
    }
    #sidebar .sidebar-header strong {
        display: block;
    }
    #sidebar ul li a {
        padding: 20px 10px;
    }
    #sidebar ul li a span {
        font-size: 0.85em;
    }
    #sidebar ul li a i {
        margin-right: 0;
        display: block;
    }
    #sidebar ul ul a {
        padding: 10px !important;
    }
    #sidebar ul li a i {
        font-size: 1.3em;
    }
    #sidebar {
        margin-left: 0;
    }
    #sidebarCollapse span {
        display: none;
    }
}
.boc{
        
        background: white;
      
        margin: 0px;
        padding: 10px;
        box-shadow: 0 0 20px 0 rgba(0 ,0, 0,0.3 );
        transition: 0.4s ease;
        border-radius: 9px;
       
    }
  
.contact{
      padding: 40px;


.image2 img {
  width: 100%;
  height: 270px;
 
}
@media only screen and (max-width: 458px) {
  .image2 img {
    width: 100%;
    height: 100%;
  }
}


</style>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                <button type="button" id="sidebarCollapse" class="btn btn-info">
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                 <span> </span>
                 </button>
               <center> <h3 style="font-size:1.5rem; font-weight:bold; color:#f3722c">Admin Dashboard</h3></center>
      
                </div>
            </nav>

    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            
            <ul class="list-unstyled components">
                <li class="active">
                    <a href="#home" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="fas fa-home"></i>
                        Home
                    </a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                        <li>
                            <a href="#">Notification</a>
                        </li>
                        <li>
                            <a href="#">Slider</a>
                        </li>
                        <li>
                            <a href="#">Technical Education</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#about">
                        <i class="fas fa-briefcase"></i>
                        Aboutus
                    </a>
                    <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                    <i class="fa fa-graduation-cap" aria-hidden="true"></i>
                        Colleges
                    </a>
                    <ul class="collapse list-unstyled" id="pageSubmenu">
                        <li>
                            <a href="#">Government Colleges</a>
                        </li>
                        <li>
                            <a href="#">Private Colleges</a>
                        </li>
                        <li>
                            <a href="#">Aided Colleges</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#user">
                    <i class="fa fa-user" aria-hidden="true"></i>
                        Users
                    </a>
                    <a href="#tpo">
                        <i class="fas fa-briefcase"></i>
                        TPO
                    </a>
                       </li>
               
                <li>
                    <a href="#gallery">
                        <i class="fas fa-image"></i>
                        Gallery
                    </a>
                </li>
                <li>
                    <a href="#exam">
                    <i class="fa fa-clipboard" aria-hidden="true"></i>
                        Exams
                    </a>
                </li>
                <li>
                    <a href="#contact">
                    <i class="fa fa-compress" aria-hidden="true"></i>
                        Contact
                    </a>
                </li>
                <li>
                    <a href="#ncc">
                        <i class="fas fa-paper-plane"></i>
                        NCC
                    </a>
                </li>
            </ul>

            
        </nav>

        <!-- Page Content  -->
        <div id="content">
          <h2 style="color:#17A2B8; font-weight:bold;" id="home">Home :-</h2>
<section>

<div class="container-fluid">
    
    <div class="row">
    
    <div class="col-md-5" style="padding-top:20px; padding-bottom:30px;">
   <center style="font-size:1.3rem; color:#f3722c; font-weight:500;"> Add Slider</center>
      <div class="boc">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10 contact">
      <form method="post" enctype="multipart/form-data">
              
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-3">Image: </div>
                  <div class="col-md-9" style=" width:100%;"><input type="File" name="image" required></div>
              </div>
             
             
              <div class="row" style="padding-top: 10px;">
                  <div class="col-md-4"><input type="submit" name="add" value="Add to Slider"style="color: #fff; background: #f8961e;" class="btn"></div>
                 
              </div>
                  
      </form>
                </div>
      
      </div>
      </div>
    
    </div>
      
<?php
if(isset($_POST['add'])){
    $image = $_FILES['image']['name'];
$image_temp =$_FILES['image']['tmp_name'];


$target='C:/xampp/htdocs/jdmeerut/image/'.basename($_FILES['image']['name']);
$s=move_uploaded_file($image_temp, "$target");
$con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
$query="insert into slider (image) values ('$image')";
mysqli_query($con,$query);
$n=mysqli_affected_rows($con);
if($n>0){
    echo "image insert";
}
else{
    echo "try again";
}
}
?>
</section>

<?php

$con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
$query="select * from slider";
 
$q=mysqli_query($con,$query);
$rowcount=mysqli_num_rows($q);
?>
<table border="2" align="center" style="width:800px; height:auto; text-align:center;">
<tr style="background:#f8961e; color:white;">
    <th>id</th>
    <th>image</th>
    <th>Option</th>
</tr>
<?php
while($p = mysqli_fetch_array($q))
{
?>
<tr>
    <td><?php echo $p[0]; ?></td>
    <td><?php echo $p[1]; ?></td>
    <td>
    <a href="edit1.php?id=<?php echo $p[0]; ?>" name="edit1" style="color: #fff; background: skyblue;" class="btn">Edit</a>
    <a href="delete1.php?id=<?php echo $p[0]; ?>" name="delete1" style="color: #fff; background: violet;" class="btn">Delete</a>
    </td>
</tr>
<?php
}
?>
</table>
                



<section style="padding-top:30px;">

<div class="container-fluid">
    
    <div class="row">
    
    <div class="col-md-7" style="padding-top:20px; padding-bottom:20px;">
   <center style="font-size:1.3rem; color:#f3722c; font-weight:500;">Notification Marquee</center>
      <div class="boc">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10 contact">
      <form method="post">
              
              
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-4">text: </div>
                  <div class="col-md-8" style=" width:100%;"><input type="text" name="txt" class="form-control"></div>
              </div>
              
              <div class="row" style="padding-top: 30px;">
                  <div class="col-md-3"><input type="submit" name="taxt" value="change" style="color: #fff; background: #f8961e;" class="btn"></div>
                 </div>
                  
      </form>
                </div>

</div>
      </div>
    
    </div>


    </div>
</div>
</section>

            <?php
                  if(isset($_POST['taxt'])){
                    
                    $txt=$_POST["txt"];

                    $con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
                    $d = "insert into Marquee (txt) values ('$txt')";
                    
                    mysqli_query($con,$d);
                
                  }
            ?>




<?php

$con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
$query="select * from marquee";
 
$q=mysqli_query($con,$query);
$rowcount=mysqli_num_rows($q);
?>
<table border="2" align="center" style="width:1200px; height:auto; text-align:center;">
<tr style="background:#f8961e; color:white;">
    <th>id</th>
    <th>text</th>
    <th>Option</th>
</tr>
<?php
while($p = mysqli_fetch_array($q))
{
?>
<tr>
    <td><?php echo $p[0]; ?></td>
    <td><?php echo $p[1]; ?></td>
    <td style="width:200px;">
    <a href="edit12.php?id=<?php echo $p[0]; ?>" name="edit3" style="color: #fff; background: skyblue;" class="btn">Edit</a>
    <a href="delete12.php?id=<?php echo $p[0]; ?>" name="delete3" style="color: #fff; background: violet;" class="btn">Delete</a>
    </td>
</tr>
<?php
}
?>
</table>
                





</section>

<section>

<div class="col-md-1"></div>
    <div class="col-md-5" style="padding-top:20px;">
   <center style="font-size:1.3rem; color:#f3722c; font-weight:500;"> Add Event</center>
      <div class="boc">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10 contact">
      <form method="post">
             
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-4"> Event: </div>
                  <div class="col-md-8" style=" width:100%;"><input type="text" name="event" class="form-control"></div>
              </div>
             
             
              <div class="row" style="padding-top: 10px;">
              <div class="col-md-1"></div>
                  <div class="col-md-4"><input type="submit" name="Adde" value="Add to event"style="color: #fff; background: #f8961e;" class="btn"></div>
                
                  </div>
                  
      </form>
                </div>
      
      </div>
      </div>
    
    </div>
      
    <?php
                  if(isset($_POST['Adde'])){
                    
                    $event=$_POST["event"];

                    $con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
                    $query = "INSERT INTO `event`(`event`) VALUES ('$event')";
                    
                    mysqli_query($con,$query);
                   $p=mysqli_affected_rows($con);
                   if($p>0){
                       echo "record inserted";
                   }
                   else{
                       echo "invalid";
                   }
                    
                  }
            ?>

</section>


<section>

<div class="col-md-1"></div>
    <div class="col-md-5" style="padding-top:20px;">
   <center style="font-size:1.3rem; color:#f3722c; font-weight:500;"> Add Notice</center>
      <div class="boc">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10 contact">
      <form method="post">
      <div class="row" style="padding-bottom: 30px;">
              <div class="col-md-4">id: </div>
                  <div class="col-md-8" style=" width:100%;"><input type="text" name="nid" class="form-control"></div>
                  </div>
             
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-4"> Notice: </div>
                  <div class="col-md-8" style=" width:100%;"><input type="text" name="notice" class="form-control"></div>
              </div>
             
             
              <div class="row" style="padding-top: 10px;">
              <div class="col-md-1"></div>
                  <div class="col-md-4"><input type="submit" name="Addn" value="Add to notice"style="color: #fff; background: #f8961e;" class="btn"></div>
                
                  </div>
                  
      </form>
                </div>
      
      </div>
      </div>
    
    </div>
      
    <?php
                  if(isset($_POST['Addn'])){
                    $nid=$_POST['nid'];
                    $notice=$_POST["notice"];

                    $con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
                    $query = "INSERT INTO `notice`(`nid`, `notification`) VALUES ($nid,'$notice')";
                    
                    mysqli_query($con,$query);
                   $p=mysqli_affected_rows($con);
                   if($p>0){
                       echo "record inserted";
                   }
                   else{
                       echo "invalid";
                   }
                    
                  }
            ?>


    <div class="col-md-8" style="padding-top:20px;">
   <center style="font-size:1.3rem; color:#f3722c; font-weight:500;"> Add Notice content</center>
      <div class="boc">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10 contact">
      <form method="post" enctype="multipart/form-data">
      <div class="row" style="padding-bottom: 30px;">
              <div class="col-md-4">Notice: </div>
                  <div class="col-md-8" style=" width:100%;"> <select name="nid" class="form-control">
         <option>select Notice</option>
<?php
//for fill dynamic combobox=========
$con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
$query="select * from notice order by notification";
$rs=  mysqli_query($con, $query);
while($a=  mysqli_fetch_array($rs))
{
?>
<option value="<?php echo $a[0]; ?>">
    <?php echo $a[1]; ?></option>
         
<?php
}
//===================================
?>
     </select></div>
                  </div>
             
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-4"> File: </div>
                  <div class="col-md-8" style=" width:100%;"><input type="file" name="file" class="form-control"></div>
              </div>
             
             
              <div class="row" style="padding-top: 10px;">
              <div class="col-md-1"></div>
                  <div class="col-md-4"><input type="submit" name="fill" value="Add to file"style="color: #fff; background: #f8961e;" class="btn"></div>
                
                  </div>
                  
      </form>
                </div>
      
      </div>
      </div>
    
    </div>
   

    <?php
                  if(isset($_REQUEST['fill'])){
                    
                   extract($_REQUEST);
                   if(isset($_FILES["file"]))
                   {
                   
                    $file = $_FILES['file']['name'];
                    $file_temp =$_FILES['file']['tmp_name'];


                    $target='C:/xampp/htdocs/jdmeerut/upload/'.basename($_FILES['file']['name']);
                    $t=move_uploaded_file($file_temp, "$target");
                   }
                   $con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
                    $n="INSERT INTO `pdf`(`nid`,`file`) VALUES ($nid,'$file')";
                    
                    mysqli_query($con,$n);
                    
                    }
            ?>




     </div>
</div>
</section>



       


              



<section style="padding-top:30px;">

<div class="container-fluid">
    
    <div class="row">
    
    <div class="col-md-7" style="padding-top:20px; padding-bottom:20px;">
   <center style="font-size:1.3rem; color:#f3722c; font-weight:500;"> Board Of Technical Education,UP</center>
      <div class="boc">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10 contact">
      <form method="post" enctype="multipart/form-data">
              
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-3">Image: </div>
                  <div class="col-md-9" style=" width:100%;"><input type="File" name="image" required></div>
              </div>
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-4">Full Name: </div>
                  <div class="col-md-8" style=" width:100%;"><input type="text" name="fname" class="form-control" required></div>
              </div>
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-4">Position: </div>
                  <div class="col-md-8" style=" width:100%;"><input type="text" name="position" class="form-control" required ></div>
              </div>
              <div class="row" style="padding-top: 30px;">
                  <div class="col-md-3"><input type="submit" name="acard" value="add Card"style="color: #fff; background: #f8961e;" class="btn"></div>
                 </div>
                  
      </form>
                </div>

</div>
      </div>
    
    </div>


    </div>
</div>
</section>



            <?php
                  if(isset($_POST['acard'])){
                    
                    $fname=$_POST["fname"];
                    $position=$_POST["position"];
                

                    $image = $_FILES['image']['name'];
                    $image_temp =$_FILES['image']['tmp_name'];


                    $target='C:/xampp/htdocs/jdmeerut/image/'.basename($_FILES['image']['name']);
                    $t=move_uploaded_file($image_temp, "$target");
                    $con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
                    $n="INSERT INTO `board`(`image`, `fname`, `position`) VALUES ('$image','$fname','$position')";
                    
                    mysqli_query($con,$n);
                    
                    }
            ?>





<?php

$con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
$query="select * from board";
 
$q=mysqli_query($con,$query);
$rowcount=mysqli_num_rows($q);
?>
<table border="2" align="center" style="width:1000px; height:auto; text-align:center;">
<tr style="background:#f8961e; color:white;">
    <th>id</th>
    <th>image</th>
    <th>fname</th>
    <th>Position</th>
    <th>Option</th>
</tr>
<?php
while($p = mysqli_fetch_array($q))
{
?>
<tr>
    <td><?php echo $p[0]; ?></td>
    <td><?php echo $p[1]; ?></td>
    <td><?php echo $p[2]; ?></td>
    <td><?php echo $p[3]; ?></td>
    <td>
    <a href="edit2.php?id=<?php echo $p[0]; ?>" name="edit2" style="color: #fff; background: skyblue;" class="btn">Edit</a>
    <a href="delete2.php?id=<?php echo $p[0]; ?>" name="delete2" style="color: #fff; background: violet;" class="btn">Delete</a>
    </td>
</tr>
<?php
}
?>
</table>
                




<section style="padding-top:30px;">

<div class="container-fluid">
    
    <div class="row">
    
    <div class="col-md-7" style="padding-top:20px; padding-bottom:20px;">
   <center style="font-size:1.3rem; color:#f3722c; font-weight:500;"> Board Of Technical Education,UP</center>
      <div class="boc">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10 contact">
      <form method="post" enctype="multipart/form-data">
              
              
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-4">Description: </div>
                  <div class="col-md-8" style=" width:100%;"><textarea class="form-control" rows="4" name="description" required></textarea></div>
              </div>
              
              <div class="row" style="padding-top: 30px;">
                  <div class="col-md-3"><input type="submit" name="desp" value="Change"style="color: #fff; background: #f8961e;" class="btn"></div>
                 </div>
                  
      </form>
                </div>

</div>
      </div>
    
    </div>


    </div>
</div>
</section>

            <?php
                  if(isset($_POST['desp'])){
                    
                    $description=$_POST["description"];

                    $con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
                    $b = "insert into description (description) values ('$description')";
                    
                    mysqli_query($con,$b);
                
                  }
            ?>

<?php

$con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
$query="select * from description";
 
$q=mysqli_query($con,$query);
$rowcount=mysqli_num_rows($q);
?>
<table border="2" align="center" style="width:1200px; height:auto; text-align:center;">
<tr style="background:#f8961e; color:white;">
    <th>id</th>
    <th>description</th>
    <th>Option</th>
</tr>
<?php
while($p = mysqli_fetch_array($q))
{
?>
<tr>
    <td><?php echo $p[0]; ?></td>
    <td><?php echo $p[1]; ?></td>
    <td style="width:200px;">
    <a href="edit3.php?id=<?php echo $p[0]; ?>" name="edit3" style="color: #fff; background: skyblue;" class="btn">Edit</a>
    <a href="delete3.php?id=<?php echo $p[0]; ?>" name="delete3" style="color: #fff; background: violet;" class="btn">Delete</a>
    </td>
</tr>
<?php
}
?>
</table>
                








<h2 style="color:#17A2B8; font-weight:bold; padding-top:40px;" id="about">About Us :-</h2>
<section>

<div class="container-fluid">
    
<div class="row">
    
    <div class="col-md-6" style="padding-top:20px; padding-bottom:20px;">
   <center style="font-size:1.3rem; color:#f3722c; font-weight:500;"> About Form</center>
      <div class="boc">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10 contact">
      <form method="post" enctype="multipart/form-data">
              
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-3">Image: </div>
                  <div class="col-md-9" style=" width:100%;"><input type="File" name="image" required></div>
              </div>
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-4">Full Name: </div>
                  <div class="col-md-8" style=" width:100%;"><input type="text" name="fname" class="form-control" required></div>
              </div>
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-4">Position: </div>
                  <div class="col-md-8" style=" width:100%;"><input type="text" name="position" class="form-control" required></div>
              </div>
             
              <div class="row" style="padding-top: 10px;">
                  <div class="col-md-4"><input type="submit" name="ADD" value="Change"style="color: #fff; background: #f8961e;" class="btn"></div>
                 
              </div>
                  
      </form>
                </div>
      
      </div>
      </div>
    
    </div>




    <?php
                  if(isset($_POST['ADD'])){
                    
                    $fname=$_POST["fname"];
                    $position=$_POST["position"];
                

                    $image = $_FILES['image']['name'];
                    $image_temp =$_FILES['image']['tmp_name'];


                    $target='C:/xampp/htdocs/jdmeerut/upload/'.basename($_FILES['image']['name']);
                    $t=move_uploaded_file($image_temp, "$target");
                    $con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
                    $u="INSERT INTO `aboutcard`(`image`, `fname`, `position`) VALUES ('$image','$fname','$position')";
                    
                    mysqli_query($con,$u);
                    
                    }
            ?>

<?php

$con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
$query="select * from aboutcard";
 
$q=mysqli_query($con,$query);
$rowcount=mysqli_num_rows($q);
?>
<table border="2" align="center" style="width:1000px; height:auto; text-align:center;">
<tr style="background:#f8961e; color:white;">
    <th>id</th>
    <th>image</th>
    <th>fname</th>
    <th>Position</th>
    <th>Option</th>
</tr>
<?php
while($p = mysqli_fetch_array($q))
{
?>
<tr>
    <td><?php echo $p[0]; ?></td>
    <td><?php echo $p[1]; ?></td>
    <td><?php echo $p[2]; ?></td>
    <td><?php echo $p['position']; ?></td>
    <td>
    <a href="edit4.php?id=<?php echo $p[0]; ?>" name="edit4" style="color: #fff; background: skyblue;" class="btn">Edit</a>
    <a href="delete4.php?id=<?php echo $p[0]; ?>" name="delete4" style="color: #fff; background: violet;" class="btn">Delete</a>
    </td>
</tr>
<?php
}
?>
</table>
                


    <div class="col-md-6" style="padding-top:20px; padding-bottom:20px;">
   <center style="font-size:1.3rem; color:#f3722c; font-weight:500;"> About Form</center>
      <div class="boc">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10 contact">
      <form method="post" enctype="multipart/form-data">
      <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-4">Heading: </div>
                  <div class="col-md-8" style=" width:100%;"><input type="text" name="heading" class="form-control" required></div>
              </div>
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-4">Small Heading: </div>
                  <div class="col-md-8" style=" width:100%;"><input type="text" name="small" class="form-control" required></div>
              </div>   
      <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-4">Description: </div>
                  <div class="col-md-8" style=" width:100%;"><textarea class="form-control" rows="2" name="description" required></textarea></div>
              </div>
              
              <div class="row" style="padding-top: 30px;">
                  <div class="col-md-3"><input type="submit" name="desc" value="Change"style="color: #fff; background: #f8961e;" class="btn"></div>
                 </div>
                  
      </form>
                </div>
      
      </div>
      </div>
    
    </div>


    </div>
</div>
</section>



<?php
                  if(isset($_POST['desc'])){
                    $heading=$_POST["heading"];
                    $small=$_POST["small"];
                    $description=$_POST["description"];

                    $con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
                    $c = "INSERT INTO `aboutdesp`(`heading`, `small`, `description`) VALUES ('$heading','$small','$description')";
                    
                   $n= mysqli_query($con,$c);
                   if($n>0)
                   echo "added";
                
                  }
            ?>

<?php

$con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
$query="select * from aboutdesp";
 
$q=mysqli_query($con,$query);
$rowcount=mysqli_num_rows($q);
?>
<table border="2" align="center" style="width:1200px; height:auto; text-align:center;">
<tr style="background:#f8961e; color:white;">
    <th>id</th>
    <th>heading</th>
    <th>small heading</th>
    <th>description</th>
    <th>Option</th>
</tr>
<?php
while($p = mysqli_fetch_array($q))
{
?>
<tr>
    <td><?php echo $p[0]; ?></td>
    <td><?php echo $p[1]; ?></td>
    <td><?php echo $p[2]; ?></td>
    <td><?php echo $p[3]; ?></td>
    <td style="width:200px;">
    <a href="edit5.php?id=<?php echo $p[0]; ?>" name="edit5" style="color: #fff; background: skyblue;" class="btn">Edit</a>
    <a href="delete5.php?id=<?php echo $p[0]; ?>" name="delete5" style="color: #fff; background: violet;" class="btn">Delete</a>
    </td>
</tr>
<?php
}
?>
</table>
                





<h2 style="color:#17A2B8; font-weight:bold;" id="gallery">Gallery :-</h2>
<section>

<div class="container-fluid">
    
    <div class="row">
    
    <div class="col-md-5" style="padding-top:20px; padding-bottom:20px;">
   <center style="font-size:1.3rem; color:#f3722c; font-weight:500;"> Add image</center>
      <div class="boc">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10 contact">
      <form method="post" enctype="multipart/form-data">
              
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-3">Image: </div>
                  <div class="col-md-9" style=" width:100%;"><input type="File" name="image" required></div>
              </div>
             
             
              <div class="row" style="padding-top: 10px;">
                  <div class="col-md-4"><input type="submit" name="Addg" value="Add to gallery"style="color: #fff; background: #f8961e;" class="btn"></div>
                 
              </div>
                  
      </form>
                </div>
      
      </div>
      </div>
    
    </div>
      
<?php
if(isset($_POST['Addg'])){
    $image = $_FILES['image']['name'];
$image_temp =$_FILES['image']['tmp_name'];


$target='C:/xampp/htdocs/jdmeerut/image/'.basename($_FILES['image']['name']);
$s=move_uploaded_file($image_temp, "$target");
$con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
$query="insert into gallery (image) values ('$image')";

mysqli_query($con,$query);

}
?>



<?php

$con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
$query="select * from gallery";
 
$q=mysqli_query($con,$query);
$rowcount=mysqli_num_rows($q);
?>
<table border="2" align="center" style="width:800px; height:auto; text-align:center;">
<tr style="background:#f8961e; color:white;">
    <th>id</th>
    <th>image</th>
    <th>Option</th>
</tr>
<?php
while($p = mysqli_fetch_array($q))
{
?>
<tr>
    <td><?php echo $p[0]; ?></td>
    <td><?php echo $p[1]; ?></td>
    <td>
    <a href="edit6.php?id=<?php echo $p[0]; ?>" name="edit6" style="color: #fff; background: skyblue;" class="btn">Edit</a>
    <a href="delete6.php?id=<?php echo $p[0]; ?>" name="delete6" style="color: #fff; background: violet;" class="btn">Delete</a>
    </td>
</tr>
<?php
}
?>
</table>
                



</section>


<h2 style="color:#17A2B8; font-weight:bold;" id="exam">Exam :-</h2>
<section  style="padding-top:50px;">

<div class="container-fluid">
    
    <div class="row">
    
    <div class="col-md-5">
   <center style="font-size:1.3rem; color:#f3722c; font-weight:500;"> Add exam Slider</center>
      <div class="boc">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10 contact">
      <form method="post" enctype="multipart/form-data">
              
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-3">Image: </div>
                  <div class="col-md-9" style=" width:100%;"><input type="File" name="image" required></div>
              </div>
             
             
              <div class="row" style="padding-top: 10px;">
                  <div class="col-md-4"><input type="submit" name="addexam" value="Add to Slider"style="color: #fff; background: #f8961e;" class="btn"></div>
                 
              </div>
                  
      </form>
                </div>
      
      </div>
      </div>
    
    </div>
      
<?php
if(isset($_POST['addexam'])){
    $image = $_FILES['image']['name'];
$image_temp =$_FILES['image']['tmp_name'];


$target='C:/xampp/htdocs/jdmeerut/image/'.basename($_FILES['image']['name']);
$s=move_uploaded_file($image_temp, "$target");
$con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
$query="insert into examslider (image) values ('$image')";
mysqli_query($con,$query);

}
?>
<?php

$con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
$query="select * from examslider";
 
$q=mysqli_query($con,$query);
$rowcount=mysqli_num_rows($q);
?>
<table border="2" align="center" style="width:800px; height:auto; text-align:center;">
<tr style="background:#f8961e; color:white;">
    <th>id</th>
    <th>image</th>
    <th>Option</th>
</tr>
<?php
while($p = mysqli_fetch_array($q))
{
?>
<tr>
    <td><?php echo $p[0]; ?></td>
    <td><?php echo $p[1]; ?></td>
    <td>
    <a href="edit7.php?id=<?php echo $p[0]; ?>" name="edit7" style="color: #fff; background: skyblue;" class="btn">Edit</a>
    <a href="delete7.php?id=<?php echo $p[0]; ?>" name="delete7" style="color: #fff; background: violet;" class="btn">Delete</a>
    </td>
</tr>
<?php
}
?>
</table>
                

</section>
<section>
<div class="col-md-6" style="padding-top:20px; padding-bottom:20px;">
   <center style="font-size:1.3rem; color:#f3722c; font-weight:500;">Description of exam</center>
      <div class="boc">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10 contact">
      <form method="post" enctype="multipart/form-data">
                 
      <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-4">Description: </div>
                  <div class="col-md-8" style=" width:100%;"><textarea class="form-control" rows="2" name="description" required></textarea></div>
              </div>
              
              <div class="row" style="padding-top: 30px;">
                  <div class="col-md-3"><input type="submit" name="des" value="Change"style="color: #fff; background: #f8961e;" class="btn"></div>
                 </div>
                  
      </form>
                </div>
      
      </div>
      </div>
    
    </div>


    </div>
</div>


<?php
                  if(isset($_POST['des'])){
                
                    
                    $description=$_POST["description"];

                    $con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
                    $c = "INSERT INTO `examdsp`(`description`) VALUES ('$description')";
                    
                    mysqli_query($con,$c);
                
                  }
            ?>

<?php

$con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
$query="select * from examdsp";
 
$q=mysqli_query($con,$query);
$rowcount=mysqli_num_rows($q);
?>
<table border="2" align="center" style="width:1200px; height:auto; text-align:center;">
<tr style="background:#f8961e; color:white;">
    <th>id</th>
    <th>description</th>
    <th style="width:200px;">Option</th>
</tr>
<?php
while($p = mysqli_fetch_array($q))
{
?>
<tr>
    <td><?php echo $p[0]; ?></td>
    <td><?php echo $p[1]; ?></td>
    <td>
    <a href="edit8.php?id=<?php echo $p[0]; ?>" name="edit8" style="color: #fff; background: skyblue;" class="btn">Edit</a>
    <a href="delete8.php?id=<?php echo $p[0]; ?>" name="delete8" style="color: #fff; background: violet;" class="btn">Delete</a>
    </td>
</tr>
<?php
}
?>
</table>
                


</section>






<h2 style="color:#17A2B8; font-weight:bold;" id="ncc">NCC :-</h2>
<section>

<div class="container-fluid">
    
    <div class="row">
    
    <div class="col-md-5" style="padding-top:20px;">
   <center style="font-size:1.3rem; color:#f3722c; font-weight:500;"> Add NCC Slider</center>
      <div class="boc">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10 contact">
      <form method="post" enctype="multipart/form-data">
              
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-3">Image: </div>
                  <div class="col-md-9" style=" width:100%;"><input type="File" name="image" required></div>
              </div>
             
             
              <div class="row" style="padding-top: 10px;">
                  <div class="col-md-4"><input type="submit" name="addnc" value="Add to NCCSlider"style="color: #fff; background: #f8961e;" class="btn"></div>
                 
              </div>
                  
      </form>
                </div>
      
      </div>
      </div>
    
    </div>
      
<?php
if(isset($_POST['addnc'])){
    $image = $_FILES['image']['name'];
$image_temp =$_FILES['image']['tmp_name'];


$target='C:/xampp/htdocs/jdmeerut/image/'.basename($_FILES['image']['name']);
$s=move_uploaded_file($image_temp, "$target");
$con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
$query="insert into nccslider (image) values ('$image')";
mysqli_query($con,$query);

}
?>
<?php

$con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
$query="select * from nccslider";
 
$q=mysqli_query($con,$query);
$rowcount=mysqli_num_rows($q);
?>
<table border="2" align="center" style="width:800px; height:auto; text-align:center;">
<tr style="background:#f8961e; color:white;">
    <th>id</th>
    <th>image</th>
    <th style="width:200px;">Option</th>
</tr>
<?php
while($p = mysqli_fetch_array($q))
{
?>
<tr>
    <td><?php echo $p[0]; ?></td>
    <td><?php echo $p[1]; ?></td>
    <td>
    <a href="edit9.php?id=<?php echo $p[0]; ?>" name="edit9" style="color: #fff; background: skyblue;" class="btn">Edit</a>
    <a href="delete9.php?id=<?php echo $p[0]; ?>" name="delete9" style="color: #fff; background: violet;" class="btn">Delete</a>
    </td>
</tr>
<?php
}
?>
</table>
                


<div class="col-md-6" style="padding-top:20px; padding-bottom:20px;">
   <center style="font-size:1.3rem; color:#f3722c; font-weight:500;">Description of NCC</center>
      <div class="boc">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10 contact">
      <form method="post" enctype="multipart/form-data">
      <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-3">Image: </div>
                  <div class="col-md-9" style=" width:100%;"><input type="File" name="image" required></div>
              </div>
             
      <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-4">Description: </div>
                  <div class="col-md-8" style=" width:100%;"><textarea class="form-control" rows="2" name="description" required></textarea></div>
              </div>
              
              <div class="row" style="padding-top: 30px;">
                  <div class="col-md-3"><input type="submit" name="desimg" value="Change"style="color: #fff; background: #f8961e;" class="btn"></div>
                 </div>
                  
      </form>
                </div>
      
      </div>
      </div>
    
    </div>


    </div>
</div>


<?php
                  if(isset($_POST['desimg'])){
                
                    
                    $description=$_POST["description"];
                    $image = $_FILES['image']['name'];
                    $image_temp =$_FILES['image']['tmp_name'];
                    
                    
                    $target='C:/xampp/htdocs/jdmeerut/image/'.basename($_FILES['image']['name']);
                    $s=move_uploaded_file($image_temp, "$target");
                    $con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
                    $c = "INSERT INTO `nccdsp`(`image`, `description`) VALUES ('$image','$description')";
            
                    mysqli_query($con,$c);
                
                  }
            ?>
<?php

$con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
$query="select * from nccdsp";
 
$q=mysqli_query($con,$query);
$rowcount=mysqli_num_rows($q);
?>
<table border="2" align="center" style="width:1000px; height:auto; text-align:center;">
<tr style="background:#f8961e; color:white;">
    <th>id</th>
    <th>image</th>
    <th>description</th>
    <th style="width:200px;">Option</th>
</tr>
<?php
while($p = mysqli_fetch_array($q))
{
?>
<tr>
    <td><?php echo $p[0]; ?></td>
    <td><?php echo $p[1]; ?></td>
    <td><?php echo $p[2]; ?></td>
    
    <td>
    <a href="edit10.php?id=<?php echo $p[0]; ?>" name="edit10" style="color: #fff; background: skyblue;" class="btn">Edit</a>
    <a href="delete10.php?id=<?php echo $p[0]; ?>" name="delete10" style="color: #fff; background: violet;" class="btn">Delete</a>
    </td>
</tr>
<?php
}
?>
</table>
                




</section>



</section>

<h2 style="color:#17A2B8; font-weight:bold; padding-top:40px;" id="tpo">TPO:-</h2>
<section>

<div class="container-fluid">
    
<div class="row">
    <div class="col-md-2"></div>
    <div class="col-md-6" style="padding-top:20px; padding-bottom:20px;">
   <center style="font-size:1.3rem; color:#f3722c; font-weight:500;">Government College TPO Form</center>
      <div class="boc">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10 contact">
      <form method="post">
      
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-5">Polytechnic Name: </div>
                  <div class="col-md-7" style=" width:100%;"><input type="text" name="name" class="form-control" required></div>
              </div>
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-5">Establishment Year	: </div>
                  <div class="col-md-7" style=" width:100%;"><input type="text" name="year" class="form-control" required></div>
              </div>
           
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-5">Name Of Principal	: </div>
                  <div class="col-md-7" style=" width:100%;"><input type="text" name="nop" class="form-control" required></div>
              </div>
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-5">Phone No.	: </div>
                  <div class="col-md-7" style=" width:100%;"><input type="text" name="pno" class="form-control" required></div>
              </div>
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-5">Email Address	: </div>
                  <div class="col-md-7" style=" width:100%;"><input type="text" name="email" class="form-control" required></div>
              </div>
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-5">Name Of TPO		: </div>
                  <div class="col-md-7" style=" width:100%;"><input type="text" name="not" class="form-control" required></div>
              </div>
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-5">Designation	: </div>
                  <div class="col-md-7" style=" width:100%;"><input type="text" name="designation" class="form-control" required></div>
              </div>
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-5">Mobile No.	: </div>
                  <div class="col-md-7" style=" width:100%;"><input type="text" name="mno" class="form-control" required></div>
              </div>
           
              <div class="row" style="padding-top: 10px;">
                  <div class="col-md-4"><input type="submit" name="savetpo" value="Add TPO" style="color: #fff; background: #f8961e;" class="btn"></div>
                 
              </div>
                  
      </form>
                </div>
      
      </div>
      </div>
    
    </div>

</section>

  
<?php
if(isset($_REQUEST["savetpo"]))
{
    extract($_REQUEST);
    $con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
    $s="INSERT INTO `gtpo`(`name`, `year`, `nop`, `pno`, `email`, `not`, `designation`, `mno`) VALUES ('$name','$year','$nop','$pno','$email','$not','$designation','$mno')";
    mysqli_query($con, $s);
    $n=  mysqli_affected_rows($con);
    
    if($n>0)
        echo "record saved";
    else
        echo "try again";
    
}

?>

<?php

$con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
$query="select * from gtpo";
 
$q=mysqli_query($con,$query);
$rowcount=mysqli_num_rows($q);
?>
<table border="2" align="center" style="width:1300px; height:auto; text-align:center;">
<tr style="background:#f8961e; color:white;">
    <th>id</th>
    <th>Polytechnic Name</th>
    <th>Establishment Year</th>
    <th>Name Of Principal</th>
    <th>Phone No.</th>
    <th>Email Address</th>
    <th>Name Of TPO</th>
    <th>Designation</th>
    <th>Mobile No.</th>
    <th style="width:200px;">Option</th>
</tr>
<?php
while($p = mysqli_fetch_array($q))
{
?>
<tr>
    <td><?php echo $p[0]; ?></td>
    <td><?php echo $p[1]; ?></td>
    <td><?php echo $p[2]; ?></td>
    <td><?php echo $p[3]; ?></td>
    <td><?php echo $p[4]; ?></td>
    <td><?php echo $p[5]; ?></td>
    <td><?php echo $p[6]; ?></td>
    <td><?php echo $p[7]; ?></td>
    <td><?php echo $p[8]; ?></td>
    
    <td>
    <a href="edit10.php?id=<?php echo $p[0]; ?>" name="edit10" style="color: #fff; background: skyblue;" class="btn">Edit</a>
    <a href="delete10.php?id=<?php echo $p[0]; ?>" name="delete10" style="color: #fff; background: violet;" class="btn">Delete</a>
    </td>
</tr>
<?php
}
?>
</table>
          




</section>
<section >

<div class="container-fluid">
    
<div class="row">
    <div class="col-md-2"></div>
    <div class="col-md-6" style="padding-top:20px; padding-bottom:20px;">
   <center style="font-size:1.3rem; color:#f3722c; font-weight:500;">Aided College TPO Form</center>
      <div class="boc">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10 contact">
      <form method="post">
      
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-5">Polytechnic Name: </div>
                  <div class="col-md-7" style=" width:100%;"><input type="text" name="name" class="form-control" required></div>
              </div>
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-5">Establishment Year	: </div>
                  <div class="col-md-7" style=" width:100%;"><input type="text" name="year" class="form-control" required></div>
              </div>
           
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-5">Name Of Principal	: </div>
                  <div class="col-md-7" style=" width:100%;"><input type="text" name="nop" class="form-control" required></div>
              </div>
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-5">Phone No.	: </div>
                  <div class="col-md-7" style=" width:100%;"><input type="text" name="pno" class="form-control" required></div>
              </div>
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-5">Email Address	: </div>
                  <div class="col-md-7" style=" width:100%;"><input type="text" name="email" class="form-control" required></div>
              </div>
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-5">Name Of TPO		: </div>
                  <div class="col-md-7" style=" width:100%;"><input type="text" name="not" class="form-control" required></div>
              </div>
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-5">Designation	: </div>
                  <div class="col-md-7" style=" width:100%;"><input type="text" name="designation" class="form-control" required></div>
              </div>
              <div class="row" style="padding-bottom: 30px;">
                  <div class="col-md-5">Mobile No.	: </div>
                  <div class="col-md-7" style=" width:100%;"><input type="text" name="mno" class="form-control" required></div>
              </div>
           
              <div class="row" style="padding-top: 10px;">
                  <div class="col-md-4"><input type="submit" name="savtpo" value="Add TPO" style="color: #fff; background: #f8961e;" class="btn"></div>
                 
              </div>
                  
      </form>
                </div>
      
      </div>
      </div>
    
    </div>

</section>

  
<?php
if(isset($_REQUEST["savtpo"]))
{
    extract($_REQUEST);
    $con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
    $s="INSERT INTO `atpo`(`name`, `year`, `nop`, `pno`, `email`, `not`, `designation`, `mno`) VALUES ('$name','$year','$nop','$pno','$email','$not','$designation','$mno')";
    mysqli_query($con, $s);
    $n=  mysqli_affected_rows($con);
    
    if($n>0)
        echo "record saved";
    else
        echo "try again";
    
}

?>

<?php

$con=mysqli_connect("localhost","jdmeerut_jdmeerut","q7%d[A0W5W5H","jdmeerut_jdmeerut");
$query="select * from atpo";
 
$q=mysqli_query($con,$query);
$rowcount=mysqli_num_rows($q);
?>
<table border="2" align="center" style="width:1300px; height:auto; text-align:center;">
<tr style="background:#f8961e; color:white;">
    <th>id</th>
    <th>Polytechnic Name</th>
    <th>Establishment Year</th>
    <th>Name Of Principal</th>
    <th>Phone No.</th>
    <th>Email Address</th>
    <th>Name Of TPO</th>
    <th>Designation</th>
    <th>Mobile No.</th>
    <th style="width:200px;">Option</th>
</tr>
<?php
while($p = mysqli_fetch_array($q))
{
?>
<tr>
    <td><?php echo $p[0]; ?></td>
    <td><?php echo $p[1]; ?></td>
    <td><?php echo $p[2]; ?></td>
    <td><?php echo $p[3]; ?></td>
    <td><?php echo $p[4]; ?></td>
    <td><?php echo $p[5]; ?></td>
    <td><?php echo $p[6]; ?></td>
    <td><?php echo $p[7]; ?></td>
    <td><?php echo $p[8]; ?></td>
    
    <td>
    <a href="edit11.php?id=<?php echo $p[0]; ?>" name="edit11" style="color: #fff; background: skyblue;" class="btn">Edit</a>
    <a href="delete11.php?id=<?php echo $p[0]; ?>" name="delete11" style="color: #fff; background: violet;" class="btn">Delete</a>
    </td>
</tr>
<?php
}
?>
</table>
          













</section>






           
            </div>
    </div>

    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
    </script>
</body>

</html>