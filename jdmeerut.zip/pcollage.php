<!DOCTYPE html>
<html lang="en" style="overflow:overlay">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS -->
    <link
      rel="stylesheet"
      href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
      integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk"
      crossorigin="anonymous"
    />
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="./assets/style.css" />

    <script
      src="https://kit.fontawesome.com/8eb330855f.js"
      crossorigin="anonymous"
    ></script>
    <title>Private Colleges</title>
  </head>
  <body>
  <?php include 'header.php'; ?> 

    <section style="background-color: #577590;">
      <div class="container inner-div" style="background-color: #fff;">
        <div class="row">
          <h1 class="col-heading">
            Private Polytechnic Colleges
          </h1>
          <div class="col-md-12" style="margin-top: 50px; margin-left: 0px; ">
            <div class="table-college college-tables">
              <table class="table table-bordered" style="overflow-x: auto;">
                <thead
                  style="
                    background: -webkit-linear-gradient(
                      to right,
                      #f8961e,
                      #f3722c
                    ); /* Chrome 10-25, Safari 5.1-6 */
                    background: linear-gradient(to right, #f8961e, #f3722c);
                    color: white;
                  "
                >
                  <tr>
                    <th scope="col">SI No.</th>
                    <th scope="col">Polytechnic Name & Address</th>
                    <th scope="col">Available Courses</th>
                    <th scope="col">Aprroved Seats</th>
                  </tr>
                </thead>
              </table>

              <table class="table table-bordered gtable" style="overflow-x: auto;" >
                <tbody >
                  <tr>
                    <th  scope="row">1</th>
                    <td  >
                     
                     seth jaiprakash mukundlal mahila polytechnic ghaziabad
                    </td>
                    <td  >
                      <p>Civil Engg.</p>
                      <p>Mech. Engg. (Prod.)</p>
                      <p>Mech. Engg. (Spl. in CAD)</p>
                      <p>Mech. Engg. (Auto) Electronics Engg.</p>
                      <p>Information Technology</p>
                      <p>Mass Communication</p>
                      <p>Interior Design & Decoration</p>
                      <p>PGD in Computer Hardware & Networking</p>
                      <p>PGD in Web Designing</p>
                    </td>
                    <td >
                      <p>67</p>
                      <p>67</p>
                      <p>67</p>
                      <p>67</p>
                      <p>67</p>
                      <p>67</p>
                      <p>75</p>
                      <p>75</p>
                      <p>75</p>
                      <p>75</p>
                    </td>
                  </tr>

                  <tr>
                    <th  scope="row">2</th>
                    <td  >
                      
                      ingraham polytechnic hapur road ghaziabad

                      
                      
                    </td>
                    <td  >
                      <p>Electronics Engg.</p>
                      <p>Computer Science & Engg.</p>
                      <p>PGD in Computer Hardware & Networking.</p>

                      <p>PGD in Web Designing</p>
                    </td>
                    <td >
                      <p>75</p>
                      <p>75</p>
                      <p>Not Running</p>
                      <p>Not Running</p>
                    </td>
                  </tr>

                  <tr>
                    <th  scope="row">3</th>
                    <td  >
                      
                      institute of international excellence garmukeswar hapur ghaziabad

                      
                      
                    </td>
                    <td >
                      <p>Electronics Engg.</p>
                      <p>Computer Science & Engg.</p>
                      <p>PGD in Computer Hardware & Networking.</p>

                      <p>PGD in Web Designing</p>
                    </td>
                    <td>
                      <p>75</p>
                      <p>75</p>
                      <p>Not Running</p>
                      <p>Not Running</p>
                    </td>
                  </tr>

                  <tr>
                    <th  scope="row">4</th>
                    <td >
                     
                     dr. ram manohar lohia college of pharmacy gt road modinagar ghaziabad

                     
                    </td>
                    <td >
                      <p>Electronics Engg.</p>
                      <p>Computer Science & Engg.</p>
                      <p>PGD in Computer Hardware & Networking.</p>

                      <p>PGD in Web Designing</p>
                    </td>
                    <td>
                      <p>75</p>
                      <p>75</p>
                      <p>Not Running</p>
                      <p>Not Running</p>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">5</th>
                    <td>
                      bbdit college of pharmacy ghaziabad
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">6</th>
                    <td>
                      satya college of engineering gram mukeempur pilkhuwa ghaziabad</td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">7</th>
                    <td>
                      r d foundation group of institute NH 58 kadarabad modinagar ghaziabad
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">8</th>
                    <td>
                      new era college of science & technology ,616,bheemkanpur
                      duhai, block-rajapur,ghaziabad
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">9</th>
                    <td>
                      international college of engineering ,delhi-meerut road
                      ,ghaziabad
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">10</th>
                    <td>
                      modinagar institute of technology ,3RD KM, niwari road modinagar
                      ,ghaziabad
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">11</th>
                    <td>
                      k s jain institute of engineering & technology , modinagar 
                      ghaziabad
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">12</th>
                    <td>
                      aryan institute of technology ,13TH KM stone,jindal nagar,
                      ghaziabad
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">13</th>
                    <td>
                      d s institute of technology and management,meerut road ,
                      ghaziabad
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">14</th>
                    <td>
                      saraswati institute of engineering & technology,24 pawla,
                      pilakhuwa,ghaziabad
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">15</th>
                    <td>
                      1560 h r institute of engineering and technolgy,
                      7 TH KM, meerut road, ghaziabad
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">16</th>
                    <td>
                      adhunik college of engineering, duhai, ghaziabad
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">17</th>
                    <td>
                      ideal institute of managemnet & technology,
                      ideal nagar sector 11,dasna, ghaziabad
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  
                  <tr>
                    <th scope="row">18</th>
                    <td>
                      vivekanad institute of technology and science,33-34
                      KM milestone ,NH-24 delhi hapur bypass,zindal
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">19</th>
                    <td>
                      j m group of institute ,hans knowledge park,34 miles,
                      delhi hapur road, ghaziabad
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">20</th>
                    <td>
                      hitech institute dasna,KM-24,ghaziabad-201015,ghaziabad
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">21</th>
                    <td>
                      dr. k. n. modi engineering college hapur road modinagar ,ghaziabad
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">22</th>
                    <td>
                      bhagwati institute of technology and science, bhagwati knowledge<br>
                      park,masauri canal makhauri,ghaziabad
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">23</th>
                    <td>
                      1585- academy of technolgy management & science ,<br>
                      achchheja NH-24,49 milestone,hapur bypass,
                      ghaziabad
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">24</th>
                    <td>
                      1621-sureshdeep polytechnic ,NH-24, delhi hapur road, ghaziabad
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">25</th>
                    <td>
                      1569-surya polytechnic for engineering & technolgy,vill-dharampur,5 biswan,
                      ghaziabad
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">26</th>
                    <td>
                      1595- sanskar college of engineering and techno, ghaziabad
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">27</th>
                    <td>
                      1147-innovate college of pharmacy badalpur gautambuddha nagar
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">28</th>
                    <td>
                      1643-HIMT college of pharmacy knowledge park-1 gautambuddha nagar
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">29</th>
                    <td>
                      1668-metro college of health & science research plot no. 41 
                      knowledge park-||| gautambuddha nagar


                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">30</th>
                    <td>
                      1992-IIMT college of pharmacy plot no. -20 knowledge park -||| gautambuddha nagar
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">31</th>
                    <td>
                      1691, ramaish institute of vocational & technical education ,<br>
                      knowledge park-| ,kasna road greater noida , gautambuddha nagar 

                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">32</th>
                    <td>
                      1648-vishvsaria institute od polytechnic village-beel, akbarpur,<br>
                      dadri,gautambuddha nagar
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">33</th>
                    <td>
                      1669-ramaish institute of vocational & technolgy education,<br>
                      knowledge park-|, Gr noida gb nagar
                      
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <th scope="row">34</th>
                    <td>
                      1515- prince institute of innovate technology ,plot no. -9,<br>
                      knowlwdge park-|||,Gr noida, gautambuddha nagar 
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
 <tr>
<th scope="row">35</th>
<td>
1641- CH. charan singh college of engineering,janchana, <br>
mohammedpur,jadaun,javer,gautambuddha nagar-203209
                      
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">36</th>
  <td>
  1989-R.V. northland institute dadri gautambuddha nagar 
                        
  </td>
  <td></td>
  <td></td>
</tr>
<tr>
  <th scope="row">37</th>
<td>
1652, accurate institute of polytechnic
,plot no.-49, <br>knowledge park-|||
gautambuddha nagar-201306
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">38</th>
<td>
1905-chaudhary charan singh college of
pharmacy plot no.-102 <br> janchana post-mehmmudpur jadaun
,jewar ,gautambuddha nagar
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">39</th>
<td>
1949-GNIT college of pharmacy plot no.-6C
knowlwdge park-|||,gautambuddha nagar
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">40</th>
<td>
1990-loyad institute of management and techno
,greater noida,gautambuddha nagar
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">41</th>
<td>
1570-IIMT college of polytechnic,A-20,
knowledge park-|||, <br>
greater noida,gautambuddha nagar-203209
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">42</th>
<td>
1641- CH. charan singh college of engineering,janchana, <br>
mohammedpur,jadaun,javer,gautambuddha nagar-203209
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">43</th>
<td>
1584- maharaja agrasen polytechnic college village &<br> post-
dayanatpur,gautambuddha nagar
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">43</th>
<td>
1688- greater noida polytechnic college plot no.-6B,<br>
knowledge park-2,greater noida,gautambuddha nagar
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">44</th>
<td>
 1555-K.P. engineering  and technolgy,NH-2,etmadpur,
 firozabad road,agra      
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">45</th>
<td>
1150-dev institute of technical education,
barhan,etmadpur,agra
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">46</th>
<td>
1195-DR b r ambedkar polytechnic ,prem bagh,shyam lal ki bagia,
gwalior road,agra
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">47</th>
<td>
1504-kunal professional educational academy,tehara
,gwalior road,kheragarh,agra
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">48</th>
<td>
 1505- dev technical campus,agra firozabad national
 highway,rehankhurd,agra
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">49</th>
<td>
1659-maa pitambara college of pharmacy,
nawlapur,etmadpur,agra
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">50</th>
<td>
1616-kunal college of pharmacy ,NH-2,gwalior road,tehara,agra
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">51</th>
<td>
1644-k.v. pharmacy college,kuberpur,NH-2,etmadpur
,agra-283201
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">52</th>
<td>
1970-sai nath college,kundal,sadar,agra
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">53</th>
<td>
1959-maa pitambara college of pharmacy,nawlapur,
etmadpur,   agra
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">54</th>
<td>
1978-agra public pharmacy college of diploma,artoni,
sikandarabad,



agra
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">55</th>
<td>
1002-r.b. college of pharmacy,NH-2,vill-satauli,
etmadpur,agra-283202
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">56</th>
<td>
1160-sai nath college ,near bhole baba dairy,samsabad
road, barauli aheer,agra
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">57</th>
<td>
1121-raja balwant singh polytechnic ,bichpuri,agra

                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">58</th>
<td>
1544-Neelam college of engineering & technolgy,
vill-korai,tehsil-kiroali,NH-11,  agra
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">59</th>
<td>
1617-SKY institute of management and technolgy,
ladmada,bichpuri , agra
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">60</th>
<td>
1671-anand college of pharmacy,agra
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">61</th>
<td>
1943-neelam college of pharmacy,
 korai,kiravali
 agra
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">62</th>
<td>
1945-shri siddhi vinayak college of pharmacy
rabha,kiroli,agra
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">63</th>
<td>
H.I.T.M. college of pharmacy,tehra,kehragarh,agra
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">64</th>
<td>
DR. b.p.s. college of pharmacy bakalpur,shamsabad,
fatehbad,agra
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">65</th>
<td>
  1555 
  k p engineering and technology, nh-2, etmadpur, firozabad road, 
  agra 
   

                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">66</th>
<td>
  1526, eshan college of engineering sahzadpur pauri, nh-2, agra- 
  mathura highway mathura 
   


                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">67</th>
<td>
  1619, heritage technical college, 13 km mile stone, heritage  <br>
  knowledge city fatehabad road bamrauli katr 
   


                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">68</th>
<td>
  1618, bhavya technical institute, village- tehra, tahseel- 
  khairagarh, agra 
  


                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">69</th>
<td>
  1510, gayatri college of engineering & technology, murhi, jahangir 
  pur agra 
  
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">70</th>
<td>
  1571, c b s college of polytechnic, vill- poiya, peeli pokhar, aligarh 
  road agra 
   
   


                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">71</th>
<td>
  1592, a c e college of engineering and management, 17th km agra- 
  kanpur <br> road village-surhera etmadpur agra 
   


                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">72</th>
<td>
  1665 mahamaya polytechnic of 
  information technology aligarh 
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">73</th>
<td>
  1629, vision institute of technology , shahpur madrok, aligarh agra 
  highway aligarh 
  
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">74</th>
<td>
  1005-l.t.m. college of pharmacy, aligarh 
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">75</th>
<td>
  1146-shri sai institute of pharmacy,
   laxman garhi, khair, aligarh 
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">76</th>
<td>
  1984-sai r.r. college of pharmacy, aligarh 
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">77</th>
<td>
  1645-mehalvaar institute of pharmacy,jakhaira,station road,atrauli, 
  aligarh 
 
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">78</th>
<td>
   1545 institute of technology & management, aligarh 
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">79</th>
<td>
  1599, shivdan singh institute of technology & management,
  <br>10th 
  km aligarh mathura road,aligarh 
  
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">80</th>
<td>
  1628, vivekanand college of technology and management,<br> aligar 
  mathura bypass,near khair road, 500 mt from nada pul aligarh. 
  
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">81</th>
<td>
  1687, vivekanand college of polytechnic, aligarh 
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">82</th>
<td>
  1192, a d r s institute of technology and management, 
  g.t.road,gabhana aligarh 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">83</th>
<td>
  1929-jivan jyoti institute of pharmacy,
   khair road, lodha , aligarh  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">84</th>
<td>
  1930-r.j. college of pharmacy, vill- raipur,po - dharbra, teh- khair 
  aligarh- 202265 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">85</th>
<td>
  1991 -shivdan singh institute
   of techno and management, aligarh  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">86</th>
<td>
  1629 vision institute of technology , shahpur madrok, aligarh agra 
  highway, aligarh 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">87</th>
<td>
  1559. mass college of engineering and management. &  <br>post- 
  susiyantkai_a aligarh agra road hathras 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">88</th>
<td>
  1608, a c n college of polytechnic. asian city, chherat<br> kasimpur 
power house road. aligarh 

                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">89</th>
<td>
  1545, institute of technology & management,aligarh  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">90</th>
<td>
  1513,mahalwar institute of technology, vill- jakhriya. station 
  road atrauli aligarh 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">91</th>
<td>
  1642,shri moti smriti institute of technology. khasragata  <br>no- 
  4/2.17, 18,23155.56 and taj kailsha.roao.amroha-244221 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">92</th>
<td>
  1925-y.n_s. college of pharmacy and research centre , hasanpur, dist- 
  amroha 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">93</th>
<td>
  1987-gajraula college of pharmacy and reseach center gajraula, 
  amroha. 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">94</th>
<td>
  1988-d.n.s. college of pharmacy, didauli amroha 
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">95</th>
<td>
  1622 - w t m college of polytechnic, village- fatehpur, post- 
  pal-aula amroha 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">96</th>
<td>
  1511, indraprastha institute of technology, 10th km,<br> delhi 
  moradabad highway shahbazpur kala post- rajja amroha 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">97</th>
<td>
  1542. d n s college of engineering
   & technology, didauli, amroha  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">98</th>
<td>
  1562, maharaja agrasen college of engineering and technology, 
  amroha 
    
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">99</th>
<td>
  1500. i m s college of polytechnic, khungawali near brajghat. 
  amroha  
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">100</th>
<td>
  1586, i m s college of engineering, 94 mile stone, bhagwanpur 
  khadar <br> tahseel-hasanpur, near brajghat amroha 
    
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">101</th>
<td>
  1632 amani group of institution, bijnore road, amroha  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">102</th>
<td>
  1633, landmark technical campus, vill- didauli, delhi moradabad 
  road amroha 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">103</th>
<td>
  1502, gayatri devi institute of management and technology, baraut
  bagpat 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">104</th>
<td>
  1558, sri krishna college of engineering,
  singhawali,aheer, bagpat  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">105</th>
<td>
  1590 om sai institute of technology & science,om sai nagar.delhi 
baghpat road, baghpat 

                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">106</th>
<td>
  1159- indo universal college of management & technology, <br>vill- 
  bawli near chhachharpljr baraut,bagpat 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">107</th>
<td>
  1647, lakhmir institute of engineering ano technology, <br>
  gopinagar era post- bagpat,bagpat-250609 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">108</th>
<td>
  1679-saras college of pharmacy, merrut karnal highway, vill- 
  sarora baghpat 
    
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">109</th>
<td>
  1152 shri krishna college of engineering,
   sinchawali aheer, baghpat 
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">110</th>
<td>
  1130 - shri gopichand college of pharmacy,
   ahera, baghpat  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">111</th>
<td>
  1909-lakhmi chand patwari college of pharmacy, main road, khekda
  baghpat
    
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">112</th>
<td>
  1573. veer kijnwar institute of technology. bijnour, v k puram. 
  nagina road bijnour 
    
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">113</th>
<td>
  1139-krishna college of pharmacy, noorpur road, bijnor   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row"></th>
<td>
  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">114</th>
<td>
  1142-vivek college of technical education, bijnore  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">115</th>
<td>
  1659-krishna institute. nupur road
  , bijnor,hasampur. bijnor-246701  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">116</th>
<td>
  71-veer kunwar college of pharmacy, v.k. puram nagla road, 
  bijnor. 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">117</th>
<td>
  1690, janta college of polytechnic, noorpur, bijnore   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">118</th>
<td>
  1689, krishna institute of polytechnic,
   6 km stone, noorpur, bijnore  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">119</th>
<td>
  1975-swami kalyan dev pharmacy college bijnor.   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">120</th>
<td>
  1658 janta polytechnic of pharmacy,noorpur, 
  post-khas, <br>tahseel-chandpur,bijnor-246834 
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">121</th>
<td>
  1976-r.g.n.p. college of pharmacy, 
  raja ka tajpur, bijnor.  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">122</th>
<td>
  1985-krishna pharmacy college,bijnor  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">123</th>
<td>
  1997-lakshya college of management and technology, bagwara, 
  bijnor 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">124</th>
<td>
   1539, r v institute and technology, 9th km, bijnore moradabad 
  road bijnore 
    
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">125</th>
<td>
  543, north india institute of
   technology, nazibabad, bijnore   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">126</th>
<td>
  1549, k l s polytechnic college, 20th mile stone bijnor-haridwar <br>
  road near chandok village- khudehri bijnor 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">127</th>
<td>
  1972-dharamvir degree college, bishanpur, bijnor.   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">128</th>
<td>
  1907-dharamvir college of education. bishanpura, dhampur, 
  bijnor 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">129</th>
<td>
  1697-roots institute of professional education,bijnor  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">130</th>
<td>
  1939-aksh college of pharmacy, bijnor  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">131</th>
<td>
  1973-s.p. college of pharmacy, vill- tigri, post- roniya, chandpur, 
  bijnor 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">132</th>
<td>
  1977-jagmeet memorial college of pharmacy, babarpura 
  chandpur, bijnor. 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">133</th>
<td>
  1927-l.b.s.s. degree college , bijnor  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">134</th>
<td>
  1006, govt. girls polytechnic, arniya, bulandshar  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">135</th>
<td>
  1518, school of diploma engineering,shivam technical campus 
  khurja bulandsahar 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">136</th>
<td>
  1580-school of pharmacy, shivam technical campus, khurja, 
  bulandsahar 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">137</th>
<td>
  1656-bulandshahar college bulandshahar school of pharmacy, <br>
  village-pali bhavsi,auragabad road,bulandshahar-203001 
    
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">138</th>
<td>
  1698-santosh college of pharmacy, junction road khurja, bulandshahar 

 
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">139</th>
<td>
  1556 
  babu banarsi das institute of engineering technology & <br>
  research centre bulandshahr 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">140</th>
<td>
  1157-bilha college of pharmacy,
   mohan kuti, maman road, bulandshahar 
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">141</th>
<td>
  1680-j.k.institute of pharmacy
  , gt road. khurja, bulandshahar    
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">142</th>
<td>
  26 1656 bulandshahar college bulandshahar school of pharmacy, 
  village.<br> 
  palibhavsi, aurroad, bulandshahar-203001 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">143</th>
<td>
  1588, marathwara institute of technology, dhamera chhola taluka.<br> 
  sikanorabad bulandshahar 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">144</th>
<td>
  1197, v i i t college of polytechnic
   ,sunehra, bulandshahar  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">145</th>
<td>
  1674-modern international college of pharmacy, chautha kilometer <br>
  stone, main road, sikandarabad global', sikandarabad, bulandshaha 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">146</th>
<td>
  1915-hilwood medical schoolm
   roopwas panchmine , bulandshahar  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">147</th>
<td>
  1931-morden college of pharmacy,
   sikanorabad, bulandshahar  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">148</th>
<td>
  1932-maharaja agrasen college of pharmacy ahmadpur saray chabila, 
  bulandshahar 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">149</th>
<td>
  1956-b.p.s, educational institute of pharmacy, etah 
  govt. polytechnic, firozabad 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">150</th>
<td>
  1540-j.s. inst. of mgt. & tech, mainpuri road shikohabad.firozabad 
  205135 
    
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">151</th>
<td>
  1650. amardeep polytechnic college. village-kakraoo jalesar 
  road firozabad -283203 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">152</th>
<td>
  1506 ram singh college of technology. nagla 
  tundla etah road, <br>firozabad
  maoanpur, firozabad 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">153</th>
<td>
   1148 shrimant r l suman uchchatar pravidhik shaikshanik sansthan.<br> 
  madanpur firozabad 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">154</th>
<td>
  1969-f.s.college pharmacy and research center, near balajl temple, shikohabad firozabad.

 
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">155</th>
<td>
  1914 shri rameshwar college of 
  pharmacy, kandola, dhaulana ,hapur  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">156</th>
<td>
  1928-d.r, college of pharmacy, , hapur  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">157</th>
<td>
  1961-inoraprasth institute of pharmacy, indraprasth nagar garh road , 
  hapur 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">158</th>
<td>
  1672-premraghu inst'tute of pharmacy, hathras  
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">159</th>
<td>
  1958-r.b. gautam college of pharmacy, badhar, sadabad, hathras 
  mahamaya pol <br>ytechnic of information technology, mahamaya 
  nagar, hathras 
    
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">160</th>
<td>
  1137- mahamaya polytechnic of information technology. mahamaya 
  nagar 
  hathras 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">161</th>
<td>
  1651, r.b,gautam polytechnic,hathras.agra road.sadabad,hathras.

  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">162</th>
<td>
  1171, p c p s college of technology & management, vill & post- 
  uspar sonkh road mathura 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">163</th>
<td>
  1675-divya college of pharmacy, vill-sazadpur "audi farah, 
mathura 

    
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">164</th>
<td>
  1979-BDM college of  pharmacy,paigaon,chhata
  ,mathura-281401  
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">165</th>
<td>
  1982-smt. vimla devi college of pharmacy, mathura.  
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">166</th>
<td>
  1998-rajiv academy for
   pharmacy, delhi- mathura bypass, mathura 
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">167</th>
<td>
  1980- r.b.s. college of pharmacy, mathura.  
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">168</th>
<td>
  1123. sri anardevi khandelwal 
  mahila polytechnic, mathura  
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">169</th>
<td>
  1186 p k polytechnic, hathras road,mishri, sonai.block-raya.tahseel 
  maath mathura 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">170</th>
<td>
  1153- shrimati ramdulari college of technology & 
  management, 7 NR garden ole, mathura 
    
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">171</th>
<td>
  1176, mukdam bihari lal college of technology and management, <br>
  mahuan, post-farah, mathura 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">172</th>
<td>
  1623, unnati management college and technology, deendayal dham <br>
  road, daulatpur farah mathura-281122 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">173</th>
<td>
  1512, sri giriraj maharaj polytechnic college, 7 km,<br> mathura- 
  bharatpur road vill- mundesi mathura 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">174</th>
<td>
  1572, sanskriti school of poly, mathura  
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">175</th>
<td>
  1561, ishwar chand vidhya sagar institute of technology, 
  barpur, mathura 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">176</th>
<td>
  568, i v s polytechnic, 123 mile stone, mathura -delhi highway,<br> nh-2, 
  akbarpur mathura 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">177</th>
<td>
  1604, hindustan institute of technology and management,agra- 
  delhi highway NH-2 agra 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">178</th>
<td>
  1653, sachdeva polytechnic,agra delhi -281122   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">179</th>
<td>
  1151 , shivam institute of science & technolgy,
   mahawan road, 
  mathura 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">180</th>
<td>1634, b s a college of engineering, near new bus stand, bhuteyawar 
  road mathura 
  
  
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">181</th>
<td>
   1654 b.k. polytechnic,
  neemgawo road,bagho raya mathura-281204
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">182</th>
<td>
  1576, sanjay institute of technology & management, 21 mile stone,<br> 
  NH-2 vill- chaumuhan tahseel chhata mathura 
    
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">183</th>
<td>
  1177, b s m college of technology and management, vill-bhadar, 
post son, mathura 

                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">184</th>
<td>
  1170, jaswant singh bhadauria institute of technology, vill & <br> post- 
  koshikhurd, block govardhan mathura 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">185</th>
<td>
  1649- baba saheb ambedkar polytechnic, village-nagla jhinga ,post 
  mpgra, mathura-281005 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">186</th>
<td>
  1520- sanskriti institute of polytechnic 28km mathura delhi highway 
  cheata mathura 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">187</th>
<td>
  1597- p k institute of technology & management,aligarh 
  road,birhana ray mathura 
    
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">188</th>
<td>
  1700-j.s.b. college of pharmacy, kosi, khurd, mathura  
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">189</th>
<td>
  1940-a.c_s. college of
   pharmacy, kiloni, baldev, mahavan, mathura   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">190</th>
<td>
 1942- s.r.c. pharmacy college rasoolpur, gowardhan, mathura  
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">191</th>
<td>
  1981-s.g.s. college of pharmacy, mathura.  
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">192</th>
<td>
  1181, r s s college of technology and management, saidpur baldeo, 
  tahsil mahawan mathura 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">193</th>
<td>
  1185, edifi institute of polytechnic,
   sahzadpur, pauri,farha, mathura  
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">194</th>
<td>
  1154, KET polytechnic institute,
   NH- 2, farha, mathura  
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">195</th>
<td>
  1589, hardayal technical campus,24 mile stone ,agra delhi road 
  farah mathura 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">196</th>
<td>
  1695, a s m polytechnic mathura  
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">197</th>
<td>
  1145- shanti institute of technology, vill- kurali. bagpat road 
  meerut 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">198</th>
<td>
  1593 gyan bharti institute of technology ,gyan nagar,<br>
  opposite ansal sushant partapur bypass road meerut  
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">199</th>
<td>
  1594. f i t engineering college.kaseru baksar,green park,mawana 
  road meerut 
    
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">200</th>
<td>
  1603, bansal institute of engineering and technology,near pavli <br>
  khas,railway station modipuram meerut 
   
  
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">201</th>
<td>
  1605. j p institute of engineering and 
  technology<br> salarpur jalalpur mawana road meerut 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">202</th>
<td>
  1140-n k b r institute of 
  pharmacy & research, fafunda, meerut  
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">203</th>
<td>
  1156-venkateshwar college of pharmacy, NH-58, delhi roorkee <br>
  bypass,jatauli,meerut 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">204</th>
<td>
  1655-akshita college of pharmacy.village- 
  atmadnagar<br> alipur. sardhana meerut-250225 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">205</th>
<td>
  1660-merrut college of pharmacy, vill- khirwa jalalpur, the- 
  dardhana, merrut 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">206</th>
<td>
  1676-merrut college of pharmacy, khirwa jalalpur. the- 
  dardhana merrut 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">207</th>
<td>
  1678-katyavani college of education, sardhana, meerut 
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">208</th>
<td>
  1684-m.i.t institute of technology,
   pohalli, sardhana road merrut   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">209</th>
<td>
  1681-n.g.i collge of pharmacy,
   vill- pawalikhas, sarohana merrut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">210</th>
<td>
  1685-sharda college of pharmacy, vill- saulada. block-machehra, 
  garh road merrut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">211</th>
<td>
  1901-s.v.s school of pharmacy, mawana meerut   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">212</th>
<td>
  1904-kalka pharmacy institute for advance studies, baral, prtapur, 
  meerut 
    
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">213</th>
<td>
  1910.jalshri college of pharmacy,
   amarpur, hasanpur, kalan,mawana meerut. 
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">214</th>
<td>
  1172 beacon institute of technology, partapur, meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">215</th>
<td>
  1168, shanti polytechnic,
   baghpat road, vill & post- kurali,meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">216</th>
<td>
  1529, rishi institute of enginnering and technology,<br> delhi- 
dehradun bypass road. partapur meerut 

                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">217</th>
<td>
  1536, institute of technology & management, meerut-baghpat road 
  panchli khurd, meerut 
    
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">218</th>
<td>
  1178, shri balaji polytechnical college, 
  kurali baghpat road, kurali jani khurad meerut. 
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">219</th>
<td>1535, venkateshwar institute of technology, NH-58, delhi-roorkee <br>
  bypass, jatauli meerut 
  
  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">220</th>
<td>
  1162, l t r inst. of technolgy, bagpat road kurali dharmshala, 
  meerut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">221</th>
<td>
  1155, venkateshwar college of engineering, n.h.- 58, delhi roorkee 
  bypass jatauli meerut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">222</th>
<td>
  1193, neelkanth college of engineering, nh-58,near swp<br> university 
  modipuram,meerut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">223</th>
<td>
  1161, neelkanth institute of engg. & tech., nh- 58, pawli khas,<br> near s 
v b p university modipuram meerut 

                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">224</th>
<td>
  1155, venkateshwar college of engineering, n.h.- 58, delhi roorkee 
  bypass, jatauli meerut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">225</th>
<td>
  1635, vidhya college of engineering, vidhya knowledge park, 
  baghpat road meerut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">226</th>
<td>
  1911-department or pharmacy 
  meerut institute of techno, meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">227</th>
<td>
  1917-m.i.t.i t. dabthuwa meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">228</th>
<td>
  1916-shri ram college of pharmacy meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">229</th>
<td>
  1918-k.c.e. badruddin nagar. nanu,meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">230</th>
<td>
  1919-panchvati college of pharmacy. meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">231</th>
<td>
  1920-l.t.r. insti of techno kurali meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">232</th>
<td>
  1923-dayanand college of pharmacy, meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">233</th>
<td>
  1922 n.g.i.c.p modipuram , meerut 
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">234</th>
<td>
  1534, delhi institute of engineering & technology, ghat road.<br> near 
  subharti university meerut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">235</th>
<td>
  1172, beacon institute of technology. partapur, meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">236</th>
<td>
  1174. s.v.s, polytechnic. hasthinapur road mawanakala,meerut - 
  250401 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">237</th>
<td>
  1179. panchwati institute 
  of polytechnic. & post- ghat. meerut 
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">238</th>
<td>
  1180, de-ewan vs institute of hotel management & catering<br> 
  technology bypass road partapur meerut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">239</th>
<td>
  1921-bharat institute of
   technology(school of pharmacy) 
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">240</th>
<td>
  1924-meerut college of higher educational, meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">241</th>
<td>
  1948-rudra college of pharmacy, vill- mawana khurd. meerut <br>
  college of pharmacy, vill- jatoli, meerut 
    
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">242</th>
<td>
  1952-balaji college of pharmacy, opposite baghla road, kila <br>
  parikshitgarh meerut- 250408 
   
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">243</th>
<td>
  1531, shrinathji institute for technical education. ghat road,<br>delhi 
roorkee bypass meerut 

                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">244</th>
<td>
  1127 j p institute of hotel management & catering technology,<br>post 
  rajpu mawana road meerut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">245</th>
<td>
  1167, jindal institute of polytechnic, nh-58. gt road. near<br> khar- 
  khooa morh mohiuddinpur meerut 
    
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">246</th>
<td>
  1169, m.k.r.(p.g.) insta of technology, baghpat   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">247</th>
<td>
  1567, hastinapur institute of technology and management, village- 
  ganeshpur mawana meerut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">248</th>
<td>
  1533-ABSS institute
   of technology, salarpur,mawana road, meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">249</th>
<td>
  1182-subharti polytechnic college. subharathi puram,
   NH-58.delhl <br>
  hardwar meerut bypass road meerut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">250</th>
<td>
  1173, mahaveer institute of technology, post- dabthuwa.tahaseel-<br> 
  sardhana pohalli meerut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">251</th>
<td>
  1503. a p s college of education and technology,rohta <br>
  road khiwai near harra morn sardhana meerut 
    
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">252</th>
<td>
  1507,translam institute of
   technology & management,mawana road rajpura meerut   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">253</th>
<td>
  1508, r k polytechnic, kithor, meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">254</th>
<td>
  1517, sriram institute of technology, nh-58,delhl roorkee<br> bypass, 
  near sardhana crossing jatauli, meerut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">255</th>
<td>
  1521, savita devi institute of technology, delhi meerut road, 
mohiddinpur meerut 

                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">256</th>
<td>
  1607, translam institute of technology and management, mawana 
  road,razapur meerut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">257</th>
<td>
  1624, i i m t college of technology, meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">258</th>
<td>
  1962-g.b. college of
   pharmacy, jevari, khirwa road, meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">259</th>
<td>
  1963-rainbow college of higher education , meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">260</th>
<td>
  1964-dayavanti college of education. sholda, meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">261</th>
<td>
  1965-savita devi institute of pharmacy, vill- kayasth, mohiddinpur, 
  meerut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">262</th>
<td>
  1172, beacon institute of technology, partapur, meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">263</th>
<td>
  1530, college of engineering & rural technology, partapur by pass 
  road meerut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">264</th>
<td>
  1531, shrinathji institute for technical education, ghat road,delhi <br>
  roorkee bypass meerut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">265</th>
<td>
  1538, shanti niketan group of institutions, village-ikla, goon-gejha<br> 
  road. mohiuddinpur meerut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">266</th>
<td>
  1532 kite group of institutions, NH58, near subharti university, 
  meerut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">267</th>
<td>
  1552, meerut international inst.
   of tech, ghat road, meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">268</th>
<td>
  1577, sri sai college of education and technology, vill & post <br>
  jangethi near P H C ghasauli sardhana RO
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">269</th>
<td>
  1966-neelkanth college of pharmacy, 
  pawali khas sardhna, meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">270</th>
<td>
  1967-shiv narayan college of pharmacy,khirwa, jalalpur,
   sardhna 
  meerut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">271</th>
<td>
  1968-ayushi college of pharmacy, dashrath fur, sakoti, tanda, 
  meerut 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">272</th>
<td>
  1994-translam institute of pharmaceutical edu. and research, 
  mawana road meerut. 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">273</th>
<td>
  1999-m.i.e.t., paabli khas, pallavpuram, meerut  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">274</th>
<td>
  1639. sambhal college of institute and management, bilalpath, 
  sambhal-244302 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">275</th>
<td>
  1625. radha krishna polytechnic college,
   shukla kl <br> pulia haridwar 
  road, moradabad 
    
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">276</th>
<td>
  1640. radhagovind institute of technology and mechanical 7 km, <br>
  kundreki road neer r.t.o officer 2KM moradabad-244001 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">277</th>
<td>
  1906-shri satya college of higher education, lodhipur, rajput delhi 
  road moradabad 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">278</th>
<td>
  1509 moradabad polytechnic
   institute sambhal road moradabad  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">279</th>
<td>
  1001, moradabad educational trust group of institute faculty of<br> 
  pharmacy moradabad 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">280</th>
<td>
  1953-dharamvir singh rajput memo. college of pharmacy, 
  thakurdwara moradabad 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">281</th>
<td>
  1954-rajkiran college of pharmacy, yakutpur,
   moradabad  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">282</th>
<td>
  1996-r.k. college of pharmacy,
   sukla kl puliya, moradabad  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">283</th>
<td>
  1602, sri ram group of college, opposite almaspur, telephone<br> 
  parikra muzaffarnagar 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">284</th>
<td>
  1175, swami kalyandev polytechnic institute, behra sadat,<br> post- 
  kakraoli janshath muzaffarnagar 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">285</th>
<td>
  1637 bhagwant institute of technology, bhagwantpuram, 17 mile<br> 
  stone, bijnore- delhi highway,muzaffarnaga 
    
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">286</th>
<td>
  1677 bhagwant college of pharmacy, bhagwanpuram-17 km <br>
  milestone bijnore delhi highway. muzaffarnagar 60 
   
  </td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">287</th>
<td>
  1514, infinity institute of management & technology,
   opp. <br>
  radhaswami satsang bhawan muzaffar nacar road 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">288</th>
<td>
  1528, s d college of engineering & technology, jansath road,<br> 
  muzaffarnagar 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">289</th>
<td>
  1131, s d polytechnic, muzaffar nagar    
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">290</th>
<td>
  1183 shiva polytechnic institute of management college,
   jauli <br>
  road, bilaspur block- kupra, muzaffarnagar 
    
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">291</th>
<td>
  1501. shriram polytechnic,
  4th km roorkee road, muzaffarnagar  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">292</th>
<td>
  1674, apex institute of technology,village & post-kaushalganj.<br> 
distt. rampur bilaspur rampur 


                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">293</th>
<td>
  1165, rajiv memorial institute of education & technology,<br> gangoh. 
tahsil nakur saharanpur 

                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">294</th>
<td>
  1579, indraprastha institute of management and technology, <br>vill- 
  umhi kota,saharanpur-muzaffar nagar sta 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">295</th>
<td>
  1187. devbhumi institute of polytechnic, berijama. devki road. 
  saharanpur 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">296</th>
<td>
  1541. dev bhoomi group of institutions, dabki road, berijama. 
  saharanpur 
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">297</th>
<td>
  1136-doon paramedical college and hospital, ganeshpur post <br>
sunderpur tenko behat, saharanpur 

                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">298</th>
<td>
  1141-doon college of education, sunderpur, saharanpur  
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">299</th>
<td>
  1666-saharanpur pharmacy college, vill-sansarpur the-behat, 
  saharanpur 
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">300</th>
<td>
  1667-veervijay pharmacy college, vill-fatehpur bhadon, post- 
  chhuttmalpur sahaaranpur 
    
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">301</th>
<td>
  1902-pharmacy college , badoli saharanpur    
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">302</th>
<td>
  1903-pharmacy college , sunderpur, saharanpur   
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">303</th>
<td>
  1105, savitribai phule govt. girls polytechnic, kumarhera, 
  saharanpur 
     
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">304</th>
<td>
  1581, devrishi institute of polytechnic and technology, 223,<br> khand- 
  2 village-salhapur nijkur saharanpur 
    
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">305</th>
<td>
  1582. janhit institute of technology,ganguli roorkee 
  chhutmalpur saharanpur 
    
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">306</th>
<td>
  1626. shivalik institute of management and technology. <br>vill- 
  saragathal, mustakal post sadhauli ,haraiya .  
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">307</th>
<td>
  1670-krishna college of pharmacy, fatehpur kalsiya road, <br>
  maalpur post-chhutmalpur saharanpur 
  
  
  
     
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">308</th>
<td>
  1933-dream college of pharmacy janta road, saharanpur   
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">309</th>
<td>
  1944-dev bhoomi college of
   pharmacy, balliakheri, saharanpur   
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">310</th>
<td>
  1947-college of pharmacy, vill- karoli, sansarpur behat, 
  saharanpur 
    
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">311</th>
<td>
  1983-indian institute of pharmacy, saharanpur   
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">312</th>
<td>
  1188. u p college of polytechnic for research, kamalpur,<br> tahseel. 
  behat saharanpur 
    
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">313</th>
<td>
  1565, dreams college of polytechnic, 5th km janta road, 
  saharanpur 
    
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">314</th>
<td>
  1578, doon college of technical campus, v.p.o -sunderpur tanko, <br>
  saharanpur 
    
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">315</th>
<td>
  1582, janhit institute of technology, ganguli roorkee 
  chhutmalpur saharanpur 
     
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">316</th>
<td>
  1199, m i m t polytechnic,
   chhutmalpur tahaseel- behat, saharanpui    
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">317</th>
<td>
  1190, dr rajendra prasad polytechnic, sunderpur, tahaseel-behat, 
  saharanpur 
    
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">318</th>
<td>
  1198,swami vivekanand polytechnic college, manduwala,<br> post- 
  khujnabad tahseel- behat saharanpur 
     
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">319</th>
<td>
  1189. apoorva institute of technology.vill & post- mirzapur<br> pole, 
  block sandhauli kadeem behat saharanpur 
     
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">320</th>
<td>
  1184, radha govind polytechnic college. 
  gopalpur <br>akrauli tahaseel-chandausi moradabad 
     
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">321</th>
<td>
  1683-swami dayanand saraswati educational institute,<br> vill- bhawalpur, 
  bansali, sambhal 
  
    
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">322</th>
<td>
  1564 k s institute of management and technology, karaunoi road. 
  shamli 
   
  
    
   
                          
</td>
<td></td>
<td></td>
</tr>
<tr>
  <th scope="row">323</th>
<td>
  1692, m m i t shamli  
  
    
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">324</th>
<td>
  1583. bhaskar polytechnic
   college,shamli road, kairana, shamli  
  
    
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row">325</th>
<td>
  1638, roorkee engineering and management technology institute, <br>8
  km shamli panipat road state highway 12,N
  
    
  
    
   
                          
</td>
<td></td>
<td></td>
</tr><tr>
  <th scope="row"></th>
<td>
  
  
    
   
                          
</td>
<td></td>
<td></td>
</tr>






                  
                 

                  
                 
                  

                  

                  

                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>

    <?php include 'footer.php'; ?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="./assets/script.js"></script>
    <script
      src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
      integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
      integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"
      integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI"
      crossorigin="anonymous"
    ></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
  </body>
</html>
